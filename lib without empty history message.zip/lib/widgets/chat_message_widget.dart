import 'package:flutter/material.dart';
// Removed flutter/services.dart as Clipboard is handled in parent
import 'package:flutter_markdown/flutter_markdown.dart'; // For Markdown
import 'package:url_launcher/url_launcher.dart'; // For launching URLs

class ChatMessageWidget extends StatelessWidget {
  final String text;
  final bool isUser;
  final int index; // Add index to identify the message
  final bool isSelected; // Add isSelected state
  // Callback function to notify the parent screen about a long press (passes index and text)
  final Function(int, String)? onMessageLongPress;
  // Callback function to notify the parent screen about a tap (passes index)
  final Function(int)? onMessageTap;

  const ChatMessageWidget({
    super.key,
    required this.text,
    required this.isUser,
    required this.index, // Require index
    required this.isSelected, // Require isSelected state
    this.onMessageLongPress,
    this.onMessageTap, // Add tap callback
  });

  // Helper to launch URL safely
  Future<void> _launchUrl(String url, BuildContext context) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Could not launch $url'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
      print('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    // Determine background colors based on user type and selection state
    final Color regularBgColor = isUser
        ? theme.colorScheme.primaryContainer.withOpacity(0.5)
        : theme.colorScheme.surfaceVariant ?? Colors.grey.shade700; // Fallback color
    final Color selectedBgColor = isUser
        ? theme.colorScheme.primaryContainer // More opaque when selected
        : (theme.colorScheme.surfaceVariant ?? Colors.grey.shade700)
            .withOpacity(0.9); // Slightly darker/more opaque when selected

    final Color currentBgColor = isSelected ? selectedBgColor : regularBgColor;

    // Determine text color based on user type (selection doesn't change text color here)
    final Color textColor = isUser
        ? theme.colorScheme.onPrimaryContainer
        : theme.colorScheme.onSurfaceVariant;

    // Build the markdown content
    final markdownContent = MarkdownBody(
      data: text,
      selectable: true, // Keep selectable for easy text selection
      styleSheet: MarkdownStyleSheet.fromTheme(theme).copyWith(
        p: theme.textTheme.bodyMedium?.copyWith(color: textColor),
        code: theme.textTheme.bodyMedium?.copyWith(
          backgroundColor: theme.colorScheme.onSurface.withOpacity(0.1),
          color: theme.colorScheme.secondary,
          fontFamily: 'monospace',
        ),
        blockquoteDecoration: BoxDecoration(
          color: theme.colorScheme.onSurface.withOpacity(0.05),
          border: Border(left: BorderSide(color: theme.dividerColor, width: 4)),
        ),
        h1: theme.textTheme.titleLarge?.copyWith(color: textColor),
        h2: theme.textTheme.titleMedium?.copyWith(color: textColor),
        a: TextStyle(
            color: Colors.lightBlueAccent[100],
            decoration: TextDecoration.underline,
            decorationColor: Colors.lightBlueAccent[100]),
      ),
      onTapLink: (text, href, title) {
        if (href != null) {
          _launchUrl(href, context);
        }
      },
    );

    return Padding(
      // Add slight extra padding if selected to make highlight more obvious? (Optional)
      padding: EdgeInsets.symmetric(vertical: isSelected ? 6.0 : 4.0, horizontal: isSelected ? 2.0 : 0.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            // GestureDetector now handles both tap and long press
            child: GestureDetector(
              onTap: () {
                // Notify parent about the tap, passing the index
                onMessageTap?.call(index);
              },
              onLongPress: () {
                // Notify parent about long press, passing index and text
                onMessageLongPress?.call(index, text);
              },
              child: Container(
                margin: isUser
                    ? const EdgeInsets.only(left: 40.0, right: 8.0)
                    : const EdgeInsets.only(left: 8.0, right: 8.0),
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: currentBgColor, // Use the dynamic background color
                  borderRadius: BorderRadius.circular(12),
                  // Optional: Add a border when selected
                  border: isSelected
                      ? Border.all(color: theme.highlightColor.withOpacity(0.6), width: 1.5)
                      : null,
                ),
                child: markdownContent,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
