import 'dart:async'; // For Timer (throttling) and async

import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // For Clipboard
import 'package:google_generative_ai/google_generative_ai.dart'; // Gemini AI
import 'package:sqflite/sqflite.dart'; // SQLite
import 'package:path/path.dart' as p; // Path manipulation
import 'package:uuid/uuid.dart'; // UUID generation
import 'package:flutter_dotenv/flutter_dotenv.dart'; // For API Key
import 'package:url_launcher/url_launcher.dart'; // For About Us link
import 'package:connectivity_plus/connectivity_plus.dart'; // Import connectivity

// Import the message widget (adjust path if necessary)
import '../widgets/chat_message_widget.dart';

// Data structure for chat messages
class AppChatMessage {
  final String text;
  final bool isUser;
  // Add unique ID for better list handling if needed later
  // final String id;
  AppChatMessage({required this.text, required this.isUser/*, required this.id */});

  // Optional: Add equality operator if needed for list operations
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AppChatMessage &&
          runtimeType == other.runtimeType &&
          text == other.text &&
          isUser == other.isUser;

  @override
  int get hashCode => text.hashCode ^ isUser.hashCode;
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with WidgetsBindingObserver {
  // --- State Variables ---
  GenerativeModel? _model; // Make nullable, initialize in initState
  ChatSession? _chatSession; // Make nullable
  Database? _database;
  final Uuid _uuid = const Uuid();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final ScrollController _chatScrollController = ScrollController();
  final TextEditingController _textController = TextEditingController();
  bool _isLoading = false;

  final List<AppChatMessage> _currentChatMessages = [];
  List<Content> _chatHistoryForAI = [];
  String? _currentSessionId;
  String? _currentSessionTopic; // Not currently displayed, but stored
  List<Map<String, dynamic>> _chatSessionsForSidebar = [];

  final String _topicModelingPrompt = "Determine the shortest phrase which I can use as a topic for the provided question. Do not add any additional words, comments, explanations, symbols, or punctuation. question: ";

  Timer? _updateThrottleTimer;
  final Duration _throttleDuration = const Duration(milliseconds: 100);

  // --- State Variables for New Features ---
  String? _selectedMessageTextForCopy; // Holds text when long-press bar is active
  int? _selectedMessageIndex; // Holds index of the selected message for highlighting
  bool _isOffline = false; // Tracks internet connection status
  StreamSubscription<List<ConnectivityResult>>? _connectivitySubscription; // Listener for connection changes
  AppChatMessage? _lastUserMessagePendingSend; // Stores message to send when back online

  // --- Initialization and Lifecycle ---

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeModel(); // Initialize AI model
    // Call the async helper to handle DB init and chat loading
    _initializeDatabaseAndLoadChat();
    _initializeConnectivityListener(); // Start listening for connection changes
  }

  // --- NEW HELPER METHOD ---
  // Handles the asynchronous database initialization and chat loading
  Future<void> _initializeDatabaseAndLoadChat() async {
    print("Initializing database...");
    await _initializeDatabase(); // Initialize DB first
    // Check if the widget is still mounted after the await
    if (mounted) {
      print("Database initialized. Loading last session or setting up new chat...");
      await _loadLastSessionOrSetupNew(); // Then load chat data
      print("Chat loaded/setup complete.");
    } else {
      print("Widget unmounted during database initialization.");
    }
  }
  // --- END NEW HELPER METHOD ---


  // --- EXISTING METHODS (Ensure these are present) ---

  // Initializes the Generative AI model using the API key from .env
  void _initializeModel() {
    print("Initializing Generative Model...");
    final apiKey = dotenv.env['GEMINI_API_KEY'];
    if (apiKey == null || apiKey.isEmpty) {
      print('CRITICAL ERROR: GEMINI_API_KEY not found or empty in .env file.');
      // Optionally show an error message to the user
      _addErrorMessageToChat(
          "Configuration Error: Could not initialize AI. API Key is missing.");
      return; // Stop initialization if key is missing
    }
    try {
      _model = GenerativeModel(
        model: 'gemini-1.5-flash-latest', // Or your desired model
        apiKey: apiKey,
        // Optional: Add safety settings, generation config, etc.
        // safetySettings: [ SafetySetting(HarmCategory.dangerousContent, HarmBlockThreshold.medium)]
      );
      print("Generative Model initialized successfully.");
    } catch (e) {
      print("Error initializing Generative Model: $e");
      _addErrorMessageToChat(
          "Initialization Error: Failed to set up AI model. $e");
    }
  }

  // Initializes the connection status listener
  void _initializeConnectivityListener() {
    print("Initializing connectivity listener...");
    _connectivitySubscription = Connectivity()
        .onConnectivityChanged
        .listen((List<ConnectivityResult> results) {
      _updateConnectionStatus(results);
    });
    // Get initial status
    Connectivity().checkConnectivity().then(_updateConnectionStatus);
    print("Connectivity listener initialized.");
  }

  @override
  void dispose() {
    print("Disposing ChatScreen State...");
    WidgetsBinding.instance.removeObserver(this);
    _chatScrollController.dispose();
    _textController.dispose();
    _updateThrottleTimer?.cancel();
    _connectivitySubscription?.cancel(); // Cancel the listener
    // Consider closing the database if it's open and not needed elsewhere
    // _database?.close(); // Uncomment if appropriate for your app structure
    print("ChatScreen State disposed.");
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    print("App Lifecycle State Changed: $state");
    if (state == AppLifecycleState.resumed) {
      // Recheck connectivity when app resumes
      Connectivity().checkConnectivity().then(_updateConnectionStatus);
    }
  }

  // Required for WidgetsBindingObserver, even if empty
  @override
  void didChangeMetrics() {}


  // --- Database Operations ---

  // Initializes the SQLite database connection
  Future<void> _initializeDatabase() async {
    try {
      final dbPath = await getDatabasesPath();
      final path = p.join(dbPath, 'chat_history.db');
      print("Database path: $path");

      _database = await openDatabase(
        path,
        version: 1,
        onCreate: (db, version) async {
          print("Creating database tables...");
          // Table for chat sessions (conversations)
          await db.execute('''
          CREATE TABLE sessions (
            id TEXT PRIMARY KEY,
            topic TEXT,
            last_updated INTEGER NOT NULL
          )
        ''');
          // Table for individual messages within sessions
          await db.execute('''
          CREATE TABLE messages (
            id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            is_user INTEGER NOT NULL,
            text TEXT NOT NULL,
            timestamp INTEGER NOT NULL,
            FOREIGN KEY (session_id) REFERENCES sessions (id) ON DELETE CASCADE
          )
        ''');
          print("Database tables created.");
        },
        onOpen: (db) {
          print("Database opened successfully.");
        },
      );
      // Enable foreign key support if needed (good practice)
      await _database?.execute('PRAGMA foreign_keys = ON');
      print("Foreign key support enabled.");
    } catch (e) {
      print("Error initializing database: $e");
      if (mounted) {
        _addErrorMessageToChat("Database Error: Could not initialize storage. $e");
      }
    }
  }

  // Gets the ID of the most recently updated session
  Future<String?> _getLastSessionId() async {
    if (_database == null) {
      print("Error: Database not initialized in _getLastSessionId.");
      return null;
    }
    try {
      final List<Map<String, dynamic>> maps = await _database!.query(
        'sessions',
        orderBy: 'last_updated DESC',
        limit: 1,
      );
      if (maps.isNotEmpty) {
        // Safely access 'id' and cast
        final id = maps.first['id'];
        if (id is String) {
          print("Last session ID found: $id");
          return id;
        } else {
          print("Warning: Last session ID found but is not a String: $id");
          return null; // Treat non-string ID as invalid
        }
      }
      print("No sessions found in database.");
      return null;
    } catch (e) {
      print("Error getting last session ID: $e");
      return null;
    }
  }

  // Loads messages and AI history for a specific session ID
  Future<void> _loadMessagesForSession(String sessionId) async {
    if (_database == null) {
      print("Error: Database not initialized in _loadMessagesForSession.");
      if (mounted) _addErrorMessageToChat("Error: Cannot load chat, database unavailable.");
      return;
    }
    if (mounted) setState(() => _isLoading = true); // Show loading indicator

    try {
      print("Loading messages for session: $sessionId");
      final List<Map<String, dynamic>> messagesData = await _database!.query(
        'messages',
        where: 'session_id = ?',
        whereArgs: [sessionId],
        orderBy: 'timestamp ASC',
      );

      final List<Map<String, dynamic>> sessionData = await _database!.query(
        'sessions',
        where: 'id = ?',
        whereArgs: [sessionId],
        limit: 1,
      );

      final loadedMessages = <AppChatMessage>[];
      final loadedHistory = <Content>[];

      for (var msgData in messagesData) {
        // Safely access and cast data from the database map
        final text = msgData['text'] as String?;
        final isUserInt = msgData['is_user'] as int?;

        if (text == null || isUserInt == null) {
          print("Warning: Skipping message with null text or is_user in session $sessionId");
          continue; // Skip this invalid message
        }
        final isUser = isUserInt == 1;

        loadedMessages.add(AppChatMessage(text: text, isUser: isUser));
        loadedHistory.add(Content(isUser ? "user" : "model", [TextPart(text)]));
      }

      if (mounted) {
        setState(() {
          _currentChatMessages.clear();
          _currentChatMessages.addAll(loadedMessages);
          _chatHistoryForAI.clear();
          _chatHistoryForAI.addAll(loadedHistory);
          _currentSessionId = sessionId;
          _currentSessionTopic = sessionData.isNotEmpty ? sessionData.first['topic'] as String? : 'Chat'; // Default topic if needed

          // Re-initialize the chat session with the loaded history
          if (_model != null) {
            // Ensure history is not empty before starting chat
            if (_chatHistoryForAI.isNotEmpty) {
              _chatSession = _model!.startChat(history: _chatHistoryForAI);
              print("Chat session re-initialized with history for session $sessionId.");
            } else {
              // If history is empty (e.g., after loading an empty session), start fresh
              _chatSession = _model!.startChat();
              print("Chat session started fresh for empty session $sessionId.");
            }
          } else {
            _chatSession = null; // Ensure chat session is null if model isn't ready
             print("Warning: Model not available when re-initializing chat session $sessionId.");
             _addErrorMessageToChat("Warning: AI Model unavailable. Cannot continue conversation.");
          }

          _isLoading = false;
          _selectedMessageIndex = null; // Clear selection when loading
          _selectedMessageTextForCopy = null;
        });
        _scrollToBottom(delayMillis: 100); // Scroll after loading
        print("Messages loaded successfully for session $sessionId. Count: ${loadedMessages.length}");
      }
    } catch (e) {
      print("Error loading messages for session $sessionId: $e");
      if (mounted) {
        _addErrorMessageToChat("Error loading chat history: $e");
        setState(() => _isLoading = false);
      }
    }
  }


  // Saves a single message to the database
  Future<void> _saveMessageToDatabase(AppChatMessage message, String sessionId, int timestamp) async {
    if (_database == null) {
      print("Error: Database not initialized in _saveMessageToDatabase.");
      return;
    }
    try {
      final messageId = _uuid.v4(); // Generate unique ID for the message
      await _database!.insert(
        'messages',
        {
          'id': messageId,
          'session_id': sessionId,
          'is_user': message.isUser ? 1 : 0,
          'text': message.text,
          'timestamp': timestamp,
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      // Update the session's last_updated timestamp
      await _database!.update(
        'sessions',
        {'last_updated': timestamp},
        where: 'id = ?',
        whereArgs: [sessionId],
      );
      print("Message saved to DB (Session: $sessionId, ID: $messageId, User: ${message.isUser})");
    } catch (e) {
      print("Error saving message to database: $e");
      // Optionally show a non-blocking error to the user
    }
  }

  // Clears chat history from the UI and optionally the database
  Future<void> _clearChatHistory() async {
    print("Clearing chat history...");

    // If there are no sessions at all, just reset the UI
    if (_chatSessionsForSidebar.isEmpty && _currentSessionId == null) {
       print("No sessions exist. Resetting UI.");
       _setupInitialChatState();
       return;
    }

    // Ask for confirmation to delete ALL chats
    final confirm = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirm Deletion'),
          content: const Text('Are you sure you want to delete ALL chat sessions? This action cannot be undone.'),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(false),
            ),
            TextButton(
              style: TextButton.styleFrom(foregroundColor: Colors.redAccent),
              child: const Text('Delete All'),
              onPressed: () => Navigator.of(context).pop(true),
            ),
          ],
        );
      },
    );

    if (confirm == true) {
      print("Deletion confirmed for ALL sessions.");
      if (_database == null) {
        print("Error: Database not initialized in _clearChatHistory.");
        if (mounted) _addErrorMessageToChat("Error: Cannot clear chats, database unavailable.");
        return;
      }

      try {
        // Delete all sessions (cascades to messages)
        int count = await _database!.delete('sessions');
        print("$count sessions deleted from database.");

        // Reset UI to initial state
        if (mounted) {
          _setupInitialChatState();
          await _loadChatSessionsForSidebar(); // Refresh sidebar (should be empty)
          _showSnackbar("All chat sessions deleted.", duration: const Duration(seconds: 2));
        }
      } catch (e) {
        print("Error deleting all chat sessions: $e");
        if (mounted) _addErrorMessageToChat("Error deleting chats: $e");
      }
    } else {
      print("Chat deletion cancelled.");
    }
  }

  // Loads session IDs and topics for the sidebar
  Future<void> _loadChatSessionsForSidebar() async {
    if (_database == null) {
      print("Error: Database not initialized in _loadChatSessionsForSidebar.");
      return;
    }
    try {
      final List<Map<String, dynamic>> sessions = await _database!.query(
        'sessions',
        columns: ['id', 'topic', 'last_updated'],
        orderBy: 'last_updated DESC',
      );
      if (mounted) {
        setState(() {
          // Filter out any sessions with null IDs just in case
          _chatSessionsForSidebar = sessions.where((s) => s['id'] != null).toList();
        });
        print("Loaded ${_chatSessionsForSidebar.length} valid sessions for sidebar.");
      }
    } catch (e) {
      print("Error loading chat sessions for sidebar: $e");
      // Optionally update UI to show an error in the sidebar
    }
  }

  // --- Chat State Logic ---

  void _setupInitialChatState() {
    print("Setting up initial chat state...");
    if (!mounted) return;

    setState(() {
       _currentSessionId = null;
       _currentSessionTopic = null;
       _currentChatMessages.clear();
       _chatHistoryForAI.clear();

       const initialMessageText = "Hello! How can I help you?";
       final initialBotMessage = AppChatMessage(text: initialMessageText, isUser: false);
       _currentChatMessages.add(initialBotMessage);
       // Only add initial message to AI history if model is ready
       if (_model != null) {
         _chatHistoryForAI.add(Content("model", [TextPart(initialMessageText)]));
         _chatSession = _model!.startChat(history: _chatHistoryForAI);
         print("Initial chat session started with greeting.");
       } else {
          _chatSession = null;
          print("Initial chat state setup without active AI session (model not ready).");
       }

       _isLoading = false;
       _selectedMessageTextForCopy = null; // Ensure copy bar is hidden
       _selectedMessageIndex = null; // Ensure no message is selected
       _lastUserMessagePendingSend = null; // Clear pending message
    });
    print("Initial chat state setup complete.");
  }

  Future<void> _loadLastSessionOrSetupNew() async {
     final lastSessionId = await _getLastSessionId();
     if (lastSessionId != null) {
       print("Loading last session: $lastSessionId");
       await _loadMessagesForSession(lastSessionId);
       // Check if loading resulted in an empty chat (e.g., DB error or empty session)
       if (_currentChatMessages.isEmpty && mounted) {
           print("Warning: Session $lastSessionId loaded empty or failed to load. Starting new chat.");
           _setupInitialChatState(); // Fallback to new chat state
       }
     } else {
       print("No previous sessions found. Setting up initial chat.");
       if (mounted) _setupInitialChatState();
     }
     // Ensure selection is cleared when loading/setting up
     if (mounted) {
       setState(() {
         _selectedMessageIndex = null;
         _selectedMessageTextForCopy = null;
       });
     }
     // Refresh sidebar after loading/setup
     await _loadChatSessionsForSidebar();
  }

  Future<void> _loadChatSession(String sessionId) async {
    print("Loading clicked session: $sessionId");
    if (sessionId == _currentSessionId || _isLoading) {
       // Close drawer if open on small screens even if not switching
       if (MediaQuery.of(context).size.width < 700 && (_scaffoldKey.currentState?.isDrawerOpen ?? false)) {
          Navigator.of(context).pop();
       }
       print("Session already loaded or currently loading. Aborting load.");
      return;
    }

     if (mounted) setState(() => _isLoading = true);

    // Close drawer if open on small screens before loading
    if (MediaQuery.of(context).size.width < 700 && (_scaffoldKey.currentState?.isDrawerOpen ?? false)) {
       Navigator.of(context).pop();
       // Add a small delay to allow drawer animation to finish before loading UI changes
       await Future.delayed(const Duration(milliseconds: 250));
    }

    await _loadMessagesForSession(sessionId);
    // No need to reload sidebar here, it's just selection change

    if (mounted) {
      setState(() {
        _isLoading = false;
        _selectedMessageTextForCopy = null; // Hide copy bar when switching sessions
        _selectedMessageIndex = null; // Clear selection when switching sessions
      });
    }
  }

  Future<void> _createNewChat() async {
     print("Creating new chat...");
     if (_isLoading) return;

     // Close drawer if open on small screens before creating new chat
     if (MediaQuery.of(context).size.width < 700 && (_scaffoldKey.currentState?.isDrawerOpen ?? false)) {
        Navigator.of(context).pop();
        // Add a small delay
        await Future.delayed(const Duration(milliseconds: 250));
     }

     _setupInitialChatState(); // This already clears selection state and resets UI
     await _loadChatSessionsForSidebar(); // Refresh sidebar (will show no selection)

     _textController.clear();

     print("New chat created. Session ID is now null.");
  }

  // --- AI Interaction ---

  // Gets a short topic phrase from Gemini based on the first user message
  Future<String> _getTopicFromGemini(String userQuestion) async {
    if (_model == null) {
       print("Warning: Cannot get topic, AI model not initialized.");
       return "Chat"; // Default if model isn't ready
    }

    try {
      final response = await _model!.generateContent([
        Content.text(_topicModelingPrompt + userQuestion)
      ]);
      final topic = response.text?.trim() ?? "Chat";
      print("Generated topic: '$topic'");
      // Basic sanitization/length check
      return topic.length > 50 ? topic.substring(0, 47) + "..." : topic;
    } catch (e) {
      print("Error getting topic from Gemini: $e");
      return "Chat"; // Fallback topic
    }
  }

  // Sends message history to Gemini and gets the response
  Future<void> _getChatbotResponse() async {
    if (_chatSession == null) {
      print("Error: Chat session not initialized in _getChatbotResponse.");
      _addErrorMessageToChat("Error: AI chat session is not active. Please check configuration or restart.");
      if (mounted) setState(() => _isLoading = false);
      return;
    }

    // Ensure the history is not empty and the last message is from the user
    if (_chatHistoryForAI.isEmpty || _chatHistoryForAI.last.role != "user") {
       print("Error: Cannot send to AI. Invalid history state (empty or last message not user).");
       _addErrorMessageToChat("Error: Internal chat history state is invalid.");
       if (mounted) setState(() => _isLoading = false);
       return;
    }

    try {
      print("Sending message to AI...");
      // Send the last user message (which is a Content object) via the chat session
      var response = await _chatSession!.sendMessage(_chatHistoryForAI.last);

      final botResponseText = response.text;

      if (botResponseText == null || botResponseText.isEmpty) {
        print("AI returned an empty or null response.");
        // Check for potential safety blocks or other reasons
        if (response.promptFeedback?.blockReason != null) {
           final reason = response.promptFeedback!.blockReason;
           final safetyRatings = response.promptFeedback!.safetyRatings;
           print("AI response blocked. Reason: $reason. Ratings: $safetyRatings");
           _addErrorMessageToChat("AI response blocked due to safety settings (Reason: $reason).");
        } else {
           _addErrorMessageToChat("AI returned an empty response.");
        }
      } else {
        print("AI Response received.");
        final botMessage = AppChatMessage(text: botResponseText, isUser: false);
        final timestamp = DateTime.now().millisecondsSinceEpoch;

        // Add bot response to UI list and AI history
        if (mounted) {
          setState(() {
            _currentChatMessages.add(botMessage);
            // Add the actual model response to the history for the *next* turn
            _chatHistoryForAI.add(Content("model", [TextPart(botResponseText)]));
          });
          _scrollToBottom();
        }

        // Save bot message to DB if session exists
        if (_currentSessionId != null) {
          await _saveMessageToDatabase(botMessage, _currentSessionId!, timestamp);
        } else {
           print("Warning: Bot message not saved, no current session ID.");
        }
      }
    } on GenerativeAIException catch (e) {
       print("Generative AI Error: ${e.message}");
       _addErrorMessageToChat("AI Error: ${e.message}");
    } catch (e) {
      print("Error getting chatbot response: $e");
      _addErrorMessageToChat("An unexpected error occurred while contacting AI: $e");
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  // Adds an error message directly to the chat UI
  void _addErrorMessageToChat(String errorText) {
    if (mounted) {
      setState(() {
        // Avoid adding duplicate errors rapidly
        if (_currentChatMessages.isEmpty || !_currentChatMessages.last.text.contains(errorText)) {
          _currentChatMessages.add(AppChatMessage(text: "⚠️ $errorText", isUser: false));
        }
        _isLoading = false; // Ensure loading indicator stops on error
      });
      _scrollToBottom();
    }
  }

  // --- Message Sending Logic ---

  // Handles sending a user message
  Future<void> _sendMessage() async {
    final text = _textController.text.trim();
    if (text.isEmpty || _isLoading || _isOffline || _selectedMessageIndex != null) {
      print("Send condition not met: Text empty: ${text.isEmpty}, Loading: $_isLoading, Offline: $_isOffline, Msg Selected: ${_selectedMessageIndex != null}");
      return; // Don't send empty, while loading, offline, or if selecting
    }

    // Check if AI model is initialized
    if (_model == null) {
       _addErrorMessageToChat("Cannot send message: AI Model is not initialized. Check API Key and restart.");
       return;
    }

    if (mounted) setState(() => _isLoading = true);
    _textController.clear();
    FocusScope.of(context).unfocus(); // Hide keyboard

    final userMessage = AppChatMessage(text: text, isUser: true);
    final timestamp = DateTime.now().millisecondsSinceEpoch;

    // Add user message immediately to UI list and AI history
    if (mounted) {
      setState(() {
        _currentChatMessages.add(userMessage);
        // Add user message to AI history *before* sending
        _chatHistoryForAI.add(Content("user", [TextPart(text)]));
      });
      _scrollToBottom();
    }


    // --- Session Handling ---
    String? targetSessionId = _currentSessionId;
    bool isNewSession = false;

    // If this is the first user message of a new chat (no session ID yet)
    if (targetSessionId == null) {
      isNewSession = true;
      print("First user message, creating new session...");
      targetSessionId = _uuid.v4(); // Generate new session ID
      final topic = await _getTopicFromGemini(text); // Get topic from AI
      final newSession = {
        'id': targetSessionId,
        'topic': topic,
        'last_updated': timestamp,
      };

      if (_database != null) {
        try {
          await _database!.insert('sessions', newSession, conflictAlgorithm: ConflictAlgorithm.replace);
          print("New session created in DB: $targetSessionId, Topic: '$topic'");
          if (mounted) {
            setState(() {
              _currentSessionId = targetSessionId; // Set the current session ID
              _currentSessionTopic = topic;
            });
            // No need to reload all sessions, just add the new one conceptually
            // await _loadChatSessionsForSidebar(); // Avoid full reload if possible
          }
        } catch (e) {
          print("Error saving new session to database: $e");
          _addErrorMessageToChat("Error starting new chat session: $e");
          if (mounted) setState(() => _isLoading = false);
          return; // Stop if session couldn't be saved
        }
      } else {
         print("Error: Database not available to save new session.");
         _addErrorMessageToChat("Error: Cannot save chat, database unavailable.");
         if (mounted) setState(() => _isLoading = false);
         return; // Stop if DB isn't ready
      }
    }

    // Save user message to DB (now we definitely have a session ID)
    await _saveMessageToDatabase(userMessage, targetSessionId, timestamp);

    // Refresh sidebar if it was a new session
    if (isNewSession) {
       await _loadChatSessionsForSidebar();
    }

    // Ensure chat session is initialized if it wasn't (e.g., model loaded after initial state)
    if (_chatSession == null && _model != null) {
       print("Initializing chat session before sending message...");
       _chatSession = _model!.startChat(history: _chatHistoryForAI);
    }

    // Get response from AI (already added user message to _chatHistoryForAI)
    await _getChatbotResponse();

    // No need to set isLoading = false here, _getChatbotResponse handles it
  }


  // --- Connectivity Handling ---

  // Updates the connection status and handles pending messages
  void _updateConnectionStatus(List<ConnectivityResult> results) {
    // Determine if offline (no connection of any type relevant for internet)
    final bool currentlyOffline = !results.contains(ConnectivityResult.wifi) &&
                                  !results.contains(ConnectivityResult.ethernet) &&
                                  !results.contains(ConnectivityResult.mobile) &&
                                  !results.contains(ConnectivityResult.vpn); // Added VPN check

    print("Connectivity changed. Current results: $results. Is Offline: $currentlyOffline");

    if (_isOffline != currentlyOffline) {
      if (mounted) {
        setState(() {
          _isOffline = currentlyOffline;
        });
        if (!currentlyOffline) {
          // Came back online
          _showSnackbar("Back online!", duration: const Duration(seconds: 2), bgColor: Colors.green[700]);
          _resendLastPendingMessageIfNeeded();
        } else {
          // Went offline
          _showSnackbar("You are offline. Messages will be sent when connection returns.", duration: const Duration(seconds: 4), bgColor: Colors.orange[800]);
        }
      }
    }
  }

  // Tries to resend the last message if it was pending due to being offline
  void _resendLastPendingMessageIfNeeded() {
    // This logic might be complex if multiple messages were attempted offline.
    // For simplicity, this example only handles the very last attempt.
    // A more robust solution might use a queue in the database.
    if (_lastUserMessagePendingSend != null && !_isOffline && !_isLoading) {
      print("Resending pending message...");
      final messageToSend = _lastUserMessagePendingSend!;
      _lastUserMessagePendingSend = null; // Clear pending state

      // Put text back in field and trigger send
      _textController.text = messageToSend.text;
      _sendMessage();
    } else {
       print("No pending message to resend or still offline/loading.");
    }
  }


  // --- Helper Method to Clear Selection ---
  void _clearSelection() {
    if (_selectedMessageIndex != null || _selectedMessageTextForCopy != null) {
      if (mounted) {
        setState(() {
          _selectedMessageIndex = null;
          _selectedMessageTextForCopy = null;
        });
        print("Selection cleared.");
      }
    }
  }

  // --- UI Building Methods ---

  AppBar _buildAppBar() {
     // --- Build Copy Action Bar ---
     if (_selectedMessageIndex != null && _selectedMessageTextForCopy != null) {
       return AppBar(
         leading: IconButton(
           icon: const Icon(Icons.close),
           tooltip: "Cancel Selection",
           onPressed: _clearSelection, // Use the helper method
         ),
         title: const Text("Copy Message"),
         centerTitle: false, // Align title left
         backgroundColor: Theme.of(context).colorScheme.secondaryContainer, // Use a distinct color
         foregroundColor: Theme.of(context).colorScheme.onSecondaryContainer,
         elevation: 2.0, // Add elevation to lift it above content
         actions: [
           IconButton(
             icon: const Icon(Icons.copy_all_outlined),
             tooltip: "Copy to Clipboard",
             onPressed: () {
               if (_selectedMessageTextForCopy != null) {
                 Clipboard.setData(ClipboardData(text: _selectedMessageTextForCopy!));
                 print("Copied to clipboard: '${_selectedMessageTextForCopy!.substring(0, (_selectedMessageTextForCopy!.length > 20 ? 20 : _selectedMessageTextForCopy!.length))}...'");
                 if (mounted) {
                   _showSnackbar("Copied to clipboard", duration: const Duration(seconds: 1));
                   _clearSelection(); // Clear selection after copying
                 }
               }
             },
           ),
         ],
       );
     }

     // --- Build Default App Bar ---
     return AppBar(
       title: Text(_currentSessionTopic ?? "Answerhub on m2s Q&A"), // Show topic if available
       centerTitle: true,
       leading: MediaQuery.of(context).size.width < 700
           ? IconButton(
               icon: const Icon(Icons.menu),
               tooltip: "Toggle History",
               // Disable drawer toggle if loading or a message is selected
               onPressed: (_isLoading || _selectedMessageIndex != null) ? null : () {
                 print("Menu button tapped.");
                 _scaffoldKey.currentState?.openDrawer();
               },
             )
           : null,
       // Add offline indicator below the AppBar
       bottom: _isOffline
           ? PreferredSize(
               preferredSize: const Size.fromHeight(24.0), // Height of the indicator bar
               child: Material( // Use Material for theming/color
                 color: Colors.orange[800], // Distinct color for offline
                 child: InkWell( // Make it tappable to recheck connection
                   onTap: () {
                      print("Offline indicator tapped, checking connectivity...");
                      Connectivity().checkConnectivity().then(_updateConnectionStatus);
                   },
                   child: Container(
                     padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
                     child: const Row(
                       mainAxisAlignment: MainAxisAlignment.center,
                       children: [
                         Icon(Icons.signal_wifi_off_outlined, size: 16, color: Colors.white),
                         SizedBox(width: 8),
                         Text(
                           "Offline - Tap to recheck connection",
                           style: TextStyle(color: Colors.white, fontSize: 12),
                         ),
                       ],
                     ),
                   ),
                 ),
               ),
             )
           : null, // No bottom widget when online
     );
   }

   // Builds the content of the sidebar (Drawer or fixed panel)
   Widget _buildSidebarContent() {
     return Column(
       children: [
         // Header with New Chat button
         Padding(
           padding: const EdgeInsets.fromLTRB(8.0, 16.0, 8.0, 8.0),
           child: ElevatedButton.icon(
             icon: const Icon(Icons.add_circle_outline),
             label: const Text("New Chat"),
             style: ElevatedButton.styleFrom(
               minimumSize: const Size(double.infinity, 40), // Make button wide
             ),
             onPressed: _isLoading ? null : _createNewChat, // Disable when loading
           ),
         ),
         const Divider(),
         // List of past chat sessions
         Expanded(
           child: _chatSessionsForSidebar.isEmpty
               ? const Center(child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Text("Your chat history will appear here.", textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
               ))
               : ListView.builder(
                   itemCount: _chatSessionsForSidebar.length,
                   itemBuilder: (context, index) {
                     final session = _chatSessionsForSidebar[index];
                     // --- Use nullable cast and check for null ---
                     final sessionId = session['id'] as String?;
                     final topic = session['topic'] as String? ?? 'Chat'; // Default topic

                     // If sessionId is null, skip this item as it's invalid
                     if (sessionId == null) {
                       print("Warning: Found session data with null ID at index $index. Skipping item.");
                       return const SizedBox.shrink(); // Return an empty widget
                     }
                     // --- End check ---

                     final bool isSelected = sessionId == _currentSessionId;

                     return ListTile(
                       leading: Icon(Icons.chat_bubble_outline, size: 18, color: isSelected ? Theme.of(context).colorScheme.primary : null),
                       title: Text(
                         topic,
                         maxLines: 1,
                         overflow: TextOverflow.ellipsis,
                         style: TextStyle(fontWeight: isSelected ? FontWeight.bold : FontWeight.normal),
                       ),
                       selected: isSelected,
                       selectedTileColor: Theme.of(context).highlightColor.withOpacity(0.15),
                       dense: true,
                       onTap: () => _loadChatSession(sessionId), // Safe: sessionId is non-null
                       // Optional: Add delete button per session
                       trailing: IconButton(
                          icon: Icon(Icons.delete_outline, size: 18, color: Colors.grey[600]),
                          tooltip: "Delete this chat",
                          visualDensity: VisualDensity.compact, // Make button smaller
                          padding: EdgeInsets.zero,
                          onPressed: () async {
                             // Confirmation before deleting specific session
                             final confirmDelete = await showDialog<bool>(
                                context: context,
                                builder: (BuildContext context) => AlertDialog(
                                  title: const Text('Delete Chat?'),
                                  content: Text('Are you sure you want to delete the chat "$topic"?'),
                                  actions: [
                                    TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Cancel')),
                                    TextButton(style: TextButton.styleFrom(foregroundColor: Colors.redAccent), onPressed: () => Navigator.of(context).pop(true), child: const Text('Delete')),
                                  ],
                                ),
                              );
                              if (confirmDelete == true && _database != null) {
                                 print("Deleting session $sessionId from sidebar action.");
                                 // Safe: sessionId is non-null
                                 await _database!.delete('sessions', where: 'id = ?', whereArgs: [sessionId]);
                                 await _loadChatSessionsForSidebar(); // Refresh list
                                 // If the deleted session was the current one, start a new chat
                                 // Safe: sessionId is non-null
                                 if (sessionId == _currentSessionId) {
                                    _createNewChat();
                                 }
                                 _showSnackbar("Chat '$topic' deleted.", duration: const Duration(seconds: 2));
                              }
                          },
                       ),
                     );
                   },
                 ),
         ),
         const Divider(),
         // Footer options (Clear All, About)
         ListTile(
           leading: Icon(Icons.delete_sweep_outlined, size: 20, color: Colors.grey[600]),
           title: const Text("Clear All Chats"),
           dense: true,
           // Disable if loading or no chats exist
           onTap: (_isLoading || _chatSessionsForSidebar.isEmpty) ? null : _clearChatHistory,
         ),
         ListTile(
           leading: Icon(Icons.info_outline, size: 20, color: Colors.grey[600]),
           title: const Text("About"),
           dense: true,
           onTap: () {
             // Close drawer if open on small screens
             if (MediaQuery.of(context).size.width < 700 && (_scaffoldKey.currentState?.isDrawerOpen ?? false)) {
                Navigator.of(context).pop();
             }
             // Show About Dialog
             showAboutDialog(
               context: context,
               applicationName: 'Answerhub on m2s Q&A',
               applicationVersion: '1.1.0', // Update version as needed
               applicationLegalese: '© 2024 Basobaso Software',
               children: [
                 const Padding(
                   padding: EdgeInsets.only(top: 15),
                   child: Text('This app uses Google\'s Generative AI (Gemini) to answer your questions. Chat history is stored locally on your device.'),
                 ),
                 Padding(
                   padding: const EdgeInsets.only(top: 10),
                   child: InkWell(
                     child: Text('Visit Basobaso Software', style: TextStyle(color: Colors.lightBlueAccent[100], decoration: TextDecoration.underline, decorationColor: Colors.lightBlueAccent[100])),
                     onTap: () => _launchUrl('https://basobaso-software.web.app/', context), // Replace with your URL
                   ),
                 ),
               ],
             );
           },
         ),
         const SizedBox(height: 8), // Bottom padding
       ],
     );
   }


   Widget _buildTextInputArea() {
    return Padding(
      // Use viewInsets to push the input field above the keyboard
      padding: EdgeInsets.only(
          left: 8.0,
          right: 8.0,
          bottom: MediaQuery.of(context).viewInsets.bottom + 8.0, // Adjust for keyboard
          top: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end, // Align items to the bottom
        children: [
          Expanded(
            child: TextField(
              controller: _textController,
              minLines: 1,
              maxLines: 5, // Allow multi-line input
              textCapitalization: TextCapitalization.sentences,
              style: const TextStyle(fontSize: 16),
              decoration: InputDecoration( // Uses InputDecorationTheme from main.dart
                hintText: _isOffline ? "Offline - Cannot send messages" : "Type your message...",
                isDense: true,
                // Theme handles filled, fillColor, border, disabledBorder etc.
              ),
              // Send on keyboard action only if conditions met
              onSubmitted: (_isLoading || _isOffline || _selectedMessageIndex != null) ? null : (_) => _sendMessage(),
              textInputAction: TextInputAction.send,
              // Disable input field if loading, offline, or a message is selected
              enabled: !_isLoading && !_isOffline && _selectedMessageIndex == null,
            ),
          ),
          const SizedBox(width: 8),
          // Use IconButton.filled for prominence, style from theme
          IconButton.filled(
            icon: const Icon(Icons.send),
            tooltip: "Send Message",
            iconSize: 24,
            // Disable send button if conditions not met
            onPressed: (_isLoading || _isOffline || _selectedMessageIndex != null || _textController.text.trim().isEmpty)
                       ? null
                       : _sendMessage,
             padding: const EdgeInsets.all(12),
             // Style is applied via IconButtonThemeData in main.dart
          ),
        ],
      ),
    );
   }

  // --- Main Build Method ---
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final bool isLargeScreen = screenWidth >= 700;

    // Chat Area Widget Definition
     Widget chatList = ListView.builder(
         controller: _chatScrollController,
         padding: const EdgeInsets.only(top: 8.0, bottom: 8.0),
         itemCount: _currentChatMessages.length,
         reverse: false, // Keep false for normal chat flow (new messages at bottom)
         itemBuilder: (context, index) {
            // Safety check, although itemCount should prevent this
            if (index >= _currentChatMessages.length) return const SizedBox.shrink();

            final message = _currentChatMessages[index];
            return ChatMessageWidget(
               key: ValueKey("msg_$index"), // Use index in key for stability during rebuilds
               text: message.text,
               isUser: message.isUser,
               index: index, // Pass the index
               isSelected: index == _selectedMessageIndex, // Pass selection state
               onMessageLongPress: (idx, text) {
                 // When a message is long-pressed, update the state
                 print("Long press detected on message index: $idx");
                 if (mounted) {
                   setState(() {
                     _selectedMessageIndex = idx;
                     _selectedMessageTextForCopy = text;
                     FocusScope.of(context).unfocus(); // Hide keyboard
                   });
                 }
               },
               onMessageTap: (idx) {
                 print("Tap detected on message index: $idx. Currently selected: $_selectedMessageIndex");
                 // If the tapped message is the currently selected one, deselect it
                 if (idx == _selectedMessageIndex) {
                   _clearSelection();
                 }
                 // --- Optional behaviors (uncomment ONE if desired) ---
                 // Optional: If you want tapping *any* message (when one is selected) to clear selection:
                 // else if (_selectedMessageIndex != null) {
                 //   _clearSelection();
                 // }
                 // Optional: If you want tapping another message to select it instead:
                 // else if (_selectedMessageIndex != null) { // Only switch if one *was* selected
                 //    setState(() {
                 //       _selectedMessageIndex = idx;
                 //       _selectedMessageTextForCopy = _currentChatMessages[idx].text;
                 //       FocusScope.of(context).unfocus();
                 //    });
                 // }
                 // --- End Optional behaviors ---
               },
            );
         },
       );

     Widget chatArea = Column(
       children: [
         Expanded(
           // Wrap the list in a GestureDetector to detect taps on the background
           child: GestureDetector(
             onTap: () {
               // If tapped outside a message bubble, clear selection and focus
               print("Tap detected on chat background area.");
               _clearSelection();
               FocusScope.of(context).unfocus();
             },
             // Use HitTestBehavior.translucent to allow taps on empty areas
             // while still allowing list scrolling and taps on list items.
             behavior: HitTestBehavior.translucent,
             child: chatList, // The ListView
           ),
         ),
         // Show loading indicator ONLY when actively sending/receiving online
         if (_isLoading && !_isOffline)
             const Padding(
                padding: EdgeInsets.symmetric(vertical: 4.0, horizontal: 16.0),
                child: LinearProgressIndicator(minHeight: 2),
             ),
         // Build the text input area (handles padding internally now)
         _buildTextInputArea(),
       ],
     );

    return Scaffold(
      key: _scaffoldKey,
      appBar: _buildAppBar(), // AppBar now handles copy bar logic based on _selectedMessageIndex
      drawer: isLargeScreen ? null : Drawer(child: _buildSidebarContent()),
      body: Row(
        children: [
          if (isLargeScreen)
              SizedBox(
                width: 260, // Fixed width for the sidebar on large screens
                child: Material( // Add Material for background color/elevation if needed
                  elevation: 1.0, // Subtle shadow
                  color: Theme.of(context).canvasColor, // Use theme's canvas color
                  child: _buildSidebarContent(),
                ),
              ),
          if (isLargeScreen) const VerticalDivider(width: 1, thickness: 1),
          Expanded(
            child: chatArea,
          ),
        ],
      ),
    );
  }

  // --- Helper Methods ---

  // Scrolls the chat list to the bottom
  void _scrollToBottom({int delayMillis = 50}) {
    // Use a small delay to ensure the list has rendered the new item
    _updateThrottleTimer?.cancel(); // Cancel any pending scroll
    _updateThrottleTimer = Timer(Duration(milliseconds: delayMillis), () {
      if (_chatScrollController.hasClients && _chatScrollController.position.hasContentDimensions) {
        _chatScrollController.animateTo(
          _chatScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOutQuad,
        );
        print("Scrolled to bottom.");
      } else {
         print("Scroll controller has no clients or content dimensions, cannot scroll.");
      }
    });
  }

  // Shows a SnackBar message
  void _showSnackbar(String message, {Duration duration = const Duration(seconds: 3), Color? bgColor}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar(); // Hide previous snackbar first
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: duration,
        backgroundColor: bgColor, // Use default if null
        behavior: SnackBarBehavior.floating, // Or .fixed
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        margin: const EdgeInsets.all(8),
      ),
    );
    print("Snackbar shown: '$message'");
  }

  // Helper to launch URL safely
  Future<void> _launchUrl(String url, BuildContext context) async {
    final Uri uri = Uri.parse(url);
    try {
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        if (context.mounted) {
          _showSnackbar('Could not launch $url', bgColor: Colors.redAccent);
        }
        print('Could not launch $url');
      }
    } catch (e) {
       print('Error launching URL $url: $e');
       if (context.mounted) {
         _showSnackbar('Error launching URL: $e', bgColor: Colors.redAccent);
       }
    }
  }

} // End _ChatScreenState
