import 'dart:async'; // For Timer (throttling) and async
// import 'dart:io'; // For Platform checks if needed (not used currently)

import 'package:flutter/material.dart';
import 'package:google_generative_ai/google_generative_ai.dart'; // Gemini AI
import 'package:sqflite/sqflite.dart'; // SQLite
import 'package:path/path.dart' as p; // Path manipulation
import 'package:uuid/uuid.dart'; // UUID generation
import 'package:flutter_dotenv/flutter_dotenv.dart'; // For API Key
import 'package:url_launcher/url_launcher.dart'; // For About Us link

// Import the message widget (adjust path if necessary)
import '../widgets/chat_message_widget.dart';

// Data structure for chat messages
class AppChatMessage {
  final String text;
  final bool isUser;
  // Add unique ID for better list handling if needed later
  // final String id;
  AppChatMessage({required this.text, required this.isUser/*, required this.id */});
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with WidgetsBindingObserver {
  // --- State Variables ---
  GenerativeModel? _model; // Make nullable, initialize in initState
  ChatSession? _chatSession; // Make nullable
  Database? _database;
  final Uuid _uuid = const Uuid();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final ScrollController _chatScrollController = ScrollController();
  final TextEditingController _textController = TextEditingController();
  bool _isLoading = false;
  // Sidebar state is now managed implicitly by Drawer/Row split
  // bool _sidebarVisible = true;
  // double _sidebarWidth = 250;

  final List<AppChatMessage> _currentChatMessages = [];
  List<Content> _chatHistoryForAI = [];
  String? _currentSessionId;
  String? _currentSessionTopic; // Not currently displayed, but stored
  List<Map<String, dynamic>> _chatSessionsForSidebar = [];

  final String _topicModelingPrompt = "Determine the shortest phrase which I can use as a topic for the provided question. Do not add any additional words, comments, explanations, symbols, or punctuation. question: ";

  Timer? _updateThrottleTimer;
  final Duration _throttleDuration = const Duration(milliseconds: 100);

  // --- Initialization and Lifecycle ---

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeModel(); // Initialize AI model
    _initializeChat(); // Initialize DB and load data async
  }
  

  void _initializeModel() {
     final apiKey = dotenv.env['GEMINI_API_KEY'];
     if (apiKey == null || apiKey.isEmpty) {
       print('CRITICAL ERROR: GEMINI_API_KEY not found or invalid in .env file');
       _model = null; // Explicitly set to null
       WidgetsBinding.instance.addPostFrameCallback((_) {
         _showSnackbar("Chat features unavailable. Chat functionality disabled.", isError: true, duration: const Duration(seconds: 10));
       });
     } else {
       try {
         _model = GenerativeModel(
           // Choose model carefully based on features needed (history, streaming)
           // 'gemini-1.5-flash-latest' is generally good. 'gemini-pro' is older.
           model: 'gemini-2.0-flash',
           apiKey: apiKey,
           // Add safety settings if needed
           // safetySettings: [
           //   SafetySetting(HarmCategory.dangerousContent, HarmBlockThreshold.medium),
           // ],
           // generationConfig: GenerationConfig(temperature: 0.7) // Adjust config
         );
         print("Gemini Model Initialized");
       } catch (e) {
           print('Failed to initialize AI Model. Please try restarting the app');
           _model = null; // Ensure model is null on init failure
           WidgetsBinding.instance.addPostFrameCallback((_) {
             _showSnackbar("Failed to initialize AI Model. Please try restarting the app.", isError: true, duration: const Duration(seconds: 10));
           });
       }
     }
  }

  Future<void> _initializeChat() async {
    _initializeModel(); // Initialize the AI model first
    await _initializeDatabase();
    await _loadLastSessionOrSetupNew();
    await _loadChatSessionsForSidebar();
    // Initial chat session setup happens within _loadLastSessionOrSetupNew/_setupInitialChatState
    if (mounted) setState(() {}); // Ensure UI reflects loaded state
  }


  @override
  void dispose() {
    _chatScrollController.dispose();
    _textController.dispose();
    _database?.close();
    _updateThrottleTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Handle app lifecycle changes if needed (e.g., pause/resume)
    super.didChangeAppLifecycleState(state);
     print("App Lifecycle State: $state");
  }

   @override
  void didChangeMetrics() {
    // This is called when screen size changes.
    // The responsive layout in build() usually handles this automatically.
    // Add logic here only if specific state adjustments are needed on resize.
    super.didChangeMetrics();
     // if (mounted) setState(() {}); // Force rebuild if necessary
  }

  // --- Database Operations ---

  // Inside class _ChatScreenState in chat_screen.dart

  // --- Database Operations ---

  /// Initializes the SQLite database connection.
  /// Creates or upgrades the chat_history table.
  /// Handles errors during initialization and safely shows a Snackbar if needed.
  Future<void> _initializeDatabase() async {
    try {
      // Get the default database location for the platform
      final dbPath = await getDatabasesPath();
      // Construct the full path to the database file
      final path = p.join(dbPath, 'chat_history.db');
      print("Database path: $path");

      // Open the database
      _database = await openDatabase(
        path,
        version: 2, // Increment version if schema changes
        onCreate: (db, version) async {
          // Executes only if the database file doesn't exist
          print("Creating database table (version $version)...");
          // SQL to create the main table
          await db.execute(
            """
            CREATE TABLE chat_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                role TEXT NOT NULL, -- 'user' or 'model'
                message TEXT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
            """,
          );
          // Optionally create indexes for faster querying on session_id and timestamp
          await db.execute("CREATE INDEX IF NOT EXISTS session_id_idx ON chat_history (session_id)");
          await db.execute("CREATE INDEX IF NOT EXISTS timestamp_idx ON chat_history (timestamp)");
          print("Chat history table and indexes created.");
        },
        onUpgrade: (db, oldVersion, newVersion) async {
          // Executes if the database file exists but the version is lower than requested
          print("Upgrading database from $oldVersion to $newVersion...");
          // Example migration: Add columns if upgrading from version 1 to 2
          if (oldVersion < 2) {
            try {
              // Check existing columns to avoid errors if run multiple times
              var columns = (await db.rawQuery('PRAGMA table_info(chat_history)')).map((col) => col['name']).toList();

              // Add session_id if it doesn't exist (from potential older schema)
              if (!columns.contains('session_id')) {
                // Provide a default value for existing rows
                await db.execute("ALTER TABLE chat_history ADD COLUMN session_id TEXT NOT NULL DEFAULT 'default_session'");
                print("session_id column added.");
              }
              // Add timestamp if it doesn't exist
              if (!columns.contains('timestamp')) {
                await db.execute("ALTER TABLE chat_history ADD COLUMN timestamp DATETIME DEFAULT CURRENT_TIMESTAMP");
                print("timestamp column added.");
              }
              // Recreate indexes after altering table, just in case
              await db.execute("CREATE INDEX IF NOT EXISTS session_id_idx ON chat_history (session_id)");
              await db.execute("CREATE INDEX IF NOT EXISTS timestamp_idx ON chat_history (timestamp)");

            } catch (e) {
              print("Error adding columns/indexes during upgrade: $e");
              // Consider more robust migration error handling if needed
            }
          }
          // Add more 'if (oldVersion < X)' blocks for future migrations
        },
      );
      print("Database initialized successfully.");

    } catch (e) {
      // Catch errors during path retrieval or database opening
      print("Database initialization error: $e");

      // --- Safely show Snackbar after initState completes ---
      // Check if the widget is still mounted before scheduling the callback
      if (mounted) {
        // Use addPostFrameCallback to run code after the first frame is built
        WidgetsBinding.instance.addPostFrameCallback((_) {
          // Check mounted *again* inside the callback, as the widget might
          // have been disposed between scheduling and execution.
          if (mounted) {
            // Now it's safe to use context to show the Snackbar
            _showSnackbar('Error initializing database: $e', isError: true);
          }
        });
      }
      // --- End safe Snackbar logic ---
    }
  }

  /// Helper method to show a styled Snackbar.
  void _showSnackbar(String message, {bool isError = false, Duration duration = const Duration(seconds: 3)}) {
    // Check if the widget is still mounted before accessing context
    if (!mounted) return;

    // Remove any currently displayed Snackbar first
    ScaffoldMessenger.of(context).removeCurrentSnackBar();
    // Show the new Snackbar
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.redAccent[100] : Colors.green[700], // Use error/success colors
        behavior: SnackBarBehavior.floating, // Make it float above bottom elements
        duration: duration,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)), // Rounded corners
        margin: const EdgeInsets.all(10), // Add margin around the Snackbar
      ),
    );
  }

// --- Other methods like _saveMessageToDatabase, _loadMessagesForSession etc. ---


  Future<String?> _getLastSessionId() async {
    if (_database == null || !_database!.isOpen) return null;
    try {
      final List<Map<String, dynamic>> result = await _database!.query(
        'chat_history',
        columns: ['session_id'],
        orderBy: 'timestamp DESC',
        limit: 1,
      );
      return result.isNotEmpty ? result.first['session_id'] as String? : null;
    } catch (e) {
      print("Database error fetching last session ID: $e");
      _showSnackbar("Error loading chat history.", isError: true);
      return null;
    }
  }

  Future<void> _loadMessagesForSession(String sessionId) async {
    if (_database == null || !_database!.isOpen) {
       _showSnackbar("Database connection lost.", isError: true);
       return;
     }

     final loadedMessages = <AppChatMessage>[];
     final loadedHistory = <Content>[];

    try {
      final List<Map<String, dynamic>> rows = await _database!.query(
        'chat_history',
        columns: ['role', 'message'],
        where: 'session_id = ?',
        whereArgs: [sessionId],
        orderBy: 'timestamp ASC',
      );

      if (rows.isEmpty) {
        print("No messages found in DB for session $sessionId");
      } else {
        for (var row in rows) {
          final role = row['role'] as String;
          final message = row['message'] as String;
          final isUser = role == 'user';
          loadedMessages.add(AppChatMessage(text: message, isUser: isUser));
           if (role == 'user' || role == 'model') {
             loadedHistory.add(Content(role, [TextPart(message)]));
           }
        }
      }
      // Update state only if mounted
      if (mounted) {
         setState(() {
           _currentChatMessages.clear();
           _currentChatMessages.addAll(loadedMessages);
           _chatHistoryForAI.clear();
           _chatHistoryForAI.addAll(loadedHistory);
           _currentSessionId = sessionId;
           _currentSessionTopic = sessionId; // Assume ID is topic initially
           // Re-initialize chat session with loaded history
           if (_model != null) {
             _chatSession = _model!.startChat(history: _chatHistoryForAI);
           } else {
              _chatSession = null; // Ensure session is null if model failed
              _showSnackbar("AI Model not available.", isError: true);
           }
           print("Loaded session $sessionId with ${_currentChatMessages.length} messages.");
         });
          _scrollToBottom(delay: 100); // Scroll after UI updates
      }

    } catch (e) {
      print("Database error loading messages for session $sessionId: $e");
      if (mounted) {
         setState(() {
           _currentChatMessages.clear();
           _chatHistoryForAI.clear();
           _currentChatMessages.add(AppChatMessage(text: "Error loading session...", isUser: false));
           _currentSessionId = null;
           _currentSessionTopic = null;
           _chatSession = _model?.startChat(); // Start fresh session if model exists
         });
      }
      _showSnackbar("Error loading messages for session.", isError: true);
    }
  }

  Future<void> _saveMessageToDatabase(String role, String message, String sessionId) async {
     if (_database == null || !_database!.isOpen) {
       print("Error: Database not available, cannot save message.");
       _showSnackbar("Error saving message (DB unavailable).", isError: true);
       return;
     }
     if (sessionId.isEmpty) {
        print("Error: Attempted to save message with empty session_id!");
        return;
     }
     try {
       await _database!.insert(
         'chat_history',
         { 'session_id': sessionId, 'role': role, 'message': message },
         conflictAlgorithm: ConflictAlgorithm.replace,
       );
       print("Message saved for session $sessionId (Role: $role)");
     } catch (e) {
       print("Database error saving message for session $sessionId: $e");
       _showSnackbar("Error saving message.", isError: true);
     }
  }

  Future<void> _clearChatHistory() async {
     if (_database == null || !_database!.isOpen) {
        _showSnackbar("Database unavailable.", isError: true);
        return;
      }
     final confirm = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Confirm Clear'),
          content: const Text('Are you sure you want to delete all chat history? This cannot be undone.'),
          actions: [
             TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Cancel')),
             TextButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: Text('Clear All', style: TextStyle(color: Colors.redAccent[100]))
             ),
          ],
        ),
     );

     if (confirm != true) return;

     try {
        final count = await _database!.delete('chat_history');
        print("Chat history cleared ($count rows deleted).");
        _showSnackbar("Chat history cleared.");
        _setupInitialChatState(); // Reset state (calls setState)
        await _loadChatSessionsForSidebar(); // Reload sidebar (calls setState)
     } catch (e) {
        print("Database error clearing history: $e");
        _showSnackbar("Error clearing history.", isError: true);
     }
  }

  Future<void> _loadChatSessionsForSidebar() async {
    if (_database == null || !_database!.isOpen) {
       if (mounted) setState(() => _chatSessionsForSidebar = [{'error': 'Database unavailable'}]);
      return;
    }
    try {
      final List<Map<String, dynamic>> rows = await _database!.rawQuery('''
          SELECT session_id, MAX(timestamp) as last_message_time
          FROM chat_history
          GROUP BY session_id
          ORDER BY last_message_time DESC
      ''');
       if (mounted) {
         setState(() => _chatSessionsForSidebar = rows);
         print("Loaded ${_chatSessionsForSidebar.length} sessions for sidebar.");
       }
    } catch (e) {
      print("Database error loading session list: $e");
       _showSnackbar("Error loading chat list.", isError: true);
       if (mounted) setState(() => _chatSessionsForSidebar = [{'error': 'Error loading history'}]);
    }
  }

  // --- Chat State Logic ---

  void _setupInitialChatState() {
    print("Setting up initial chat state...");
    if (!mounted) return; // Check if widget is still in the tree

    setState(() {
       _currentSessionId = null;
       _currentSessionTopic = null;
       _currentChatMessages.clear();
       _chatHistoryForAI.clear();

       const initialMessageText = "Hello! How can I help you?";
       _currentChatMessages.add(AppChatMessage(text: initialMessageText, isUser: false));
       _chatHistoryForAI.add(Content("model", [TextPart(initialMessageText)]));

       // Reset the AI chat session
       if (_model != null) {
         _chatSession = _model!.startChat(history: _chatHistoryForAI);
       } else {
          _chatSession = null; // Ensure session is null if model failed
       }
       _isLoading = false; // Ensure loading is off
    });
    print("Initial chat state setup complete.");
  }

  Future<void> _loadLastSessionOrSetupNew() async {
     final lastSessionId = await _getLastSessionId();
     if (lastSessionId != null) {
       print("Loading last session: $lastSessionId");
       await _loadMessagesForSession(lastSessionId); // Sets state internally
       if (_currentChatMessages.isEmpty && mounted) {
           print("Warning: Session $lastSessionId found empty. Starting new chat.");
           _setupInitialChatState(); // Sets state internally
       }
     } else {
       print("No previous sessions found. Setting up initial chat.");
       if (mounted) _setupInitialChatState(); // Sets state internally
     }
  }

  Future<void> _loadChatSession(String sessionId) async {
    print("Loading clicked session: $sessionId");
    if (sessionId == _currentSessionId || _isLoading) {
      // Close drawer if open on small screens even if session is the same
       if (MediaQuery.of(context).size.width < 700 && (_scaffoldKey.currentState?.isDrawerOpen ?? false)) {
          Navigator.of(context).pop();
       }
      return; // Avoid reloading if already active or already loading
    }

     if (mounted) setState(() => _isLoading = true);

    // Close drawer before loading starts
    if (MediaQuery.of(context).size.width < 700 && (_scaffoldKey.currentState?.isDrawerOpen ?? false)) {
       Navigator.of(context).pop();
    }

    await _loadMessagesForSession(sessionId); // Sets state internally
    await _loadChatSessionsForSidebar(); // Refresh sidebar order/highlight (sets state)

    if (mounted) setState(() => _isLoading = false);
  }

  Future<void> _createNewChat() async {
     print("Creating new chat...");
     if (_isLoading) return; // Prevent action if already loading

     // Close drawer first if open
     if (MediaQuery.of(context).size.width < 700 && (_scaffoldKey.currentState?.isDrawerOpen ?? false)) {
        Navigator.of(context).pop();
     }

     _setupInitialChatState(); // Resets state (calls setState)
     await _loadChatSessionsForSidebar(); // Updates sidebar (calls setState)

     _textController.clear(); // Clear input for new chat

     print("New chat created. Session ID: $_currentSessionId");
  }

  // --- AI Interaction ---

  Future<String?> _getTopicFromGemini(String userQuery) async {
     if (_model == null) return null; // Can't generate topic if model failed
     print("Attempting to generate topic for query: '$userQuery'");
     try {
       final prompt = "$_topicModelingPrompt '$userQuery'";
       final response = await _model!.generateContent([Content.text(prompt)]);
       final topic = response.text?.trim();

       if (topic != null && topic.isNotEmpty) {
         final cleanTopic = topic.replaceAll(RegExp('["\'*]'), '').trim();
         if (cleanTopic.isNotEmpty) {
           print("Generated Topic: '$cleanTopic'");
           return cleanTopic;
         }
       }
       print("Warning: Gemini returned empty or invalid topic ('$topic'). Response Feedback: ${response.promptFeedback}");
       return null;
     } catch (e) {
       print("Error getting topic from Gemini: $e");
       if (e is GenerativeAIException) print("Gemini API Error: ${e.message}");
       return null;
     }
   }

   Future<void> _getChatbotResponse(String userQuery) async {
     if (_chatSession == null) { // Check if chat session is initialized
        print("Error: Chat session not available.");
        _addErrorMessageToChat("Sorry, I encountered a problem connecting to the AI. Please try sending your message again.");
        // Reset loading state if this happens mid-send
        if (mounted) setState(() => _isLoading = false);
        return;
      }
     if (_currentSessionId == null || _currentSessionId!.isEmpty) {
       print("Error: Cannot get response, current_session_id is not set.");
       _addErrorMessageToChat("Sorry, there was an issue starting this chat. Please try starting a new chat.");
       if (mounted) setState(() => _isLoading = false);
       return;
     }

     // Placeholder for Bot Response
     const placeholderText = 'Thinking...';
     final botMessagePlaceholder = AppChatMessage(text: placeholderText, isUser: false);
     int placeholderIndex = -1; // Initialize index
     if(mounted) {
        setState(() {
          _currentChatMessages.add(botMessagePlaceholder);
          placeholderIndex = _currentChatMessages.length - 1; // Get index after adding
        });
        _scrollToBottom(delay: 50);
     }

     // Prepare and send message
     String accumulatedResponse = "";
     try {
       // Send the user message via the ongoing chat session
       final responseStream = _chatSession!.sendMessageStream(
           Content('user', [TextPart(userQuery)])
       );

       await for (final chunk in responseStream) {
         final textPart = chunk.text;
         if (textPart != null) {
           accumulatedResponse += textPart;
           // Throttle UI updates
           if (_updateThrottleTimer == null || !_updateThrottleTimer!.isActive) {
             if (mounted && placeholderIndex != -1 && placeholderIndex < _currentChatMessages.length) {
               setState(() {
                 _currentChatMessages[placeholderIndex] = AppChatMessage(
                     text: "$accumulatedResponse ▌", // Use blinking cursor or similar
                     isUser: false);
               });
               _scrollToBottom(); // Scroll smoothly
             }
             _updateThrottleTimer = Timer(_throttleDuration, () {});
           }
         }
       } // End stream loop

       // Final update
       if (mounted && placeholderIndex != -1 && placeholderIndex < _currentChatMessages.length) {
         setState(() {
           _currentChatMessages[placeholderIndex] =
               AppChatMessage(text: accumulatedResponse.isEmpty ? "[No response]" : accumulatedResponse, isUser: false);
         });
         _scrollToBottom(delay: 50);
       }

       // Add final response to AI history & save if not empty
       if (accumulatedResponse.isNotEmpty) {
         // _chatHistoryForAI is managed implicitly by _chatSession now? Check package docs.
         // If not, manually add: _chatHistoryForAI.add(Content("model", [Part.text(accumulatedResponse)]));
         await _saveMessageToDatabase("model", accumulatedResponse, _currentSessionId!);
       }

     } catch (e) {
       final errorMessage = "Error getting AI response: $e";
       print(errorMessage);
       if (e is GenerativeAIException) print("Gemini API Error Details: ${e.message}");
       // Update placeholder with error
       if (mounted && placeholderIndex != -1 && placeholderIndex < _currentChatMessages.length) {
         setState(() {
           _currentChatMessages[placeholderIndex] =
               AppChatMessage(text: "**Oops!**\nSomething went wrong while getting the response. Please check your internet connection or try again.", isUser: false);
         });
       }
     } finally {
        _updateThrottleTimer?.cancel();
     }
   }

   void _addErrorMessageToChat(String errorText) {
      if(mounted) {
         setState(() {
            _currentChatMessages.add(AppChatMessage(text: "**Error:**\n$errorText", isUser: false));
         });
         _scrollToBottom(delay: 50);
      }
   }

  // --- Message Sending Logic ---

  Future<void> _sendMessage() async {
    final userMessage = _textController.text.trim();
    // Check if model/session are available before proceeding
    if (userMessage.isEmpty || _isLoading || _model == null || _database == null || !_database!.isOpen) {
       if (_model == null) _showSnackbar("AI Model not available.", isError: true);
       if (_database == null || !_database!.isOpen) _showSnackbar("Database not available.", isError: true);
       return;
    }

    _textController.clear();
    FocusScope.of(context).unfocus();
    if(mounted) {
      setState(() {
        _isLoading = true;
        _currentChatMessages.add(AppChatMessage(text: userMessage, isUser: true));
      });
    }
     _scrollToBottom(delay: 50);

    String? currentSessionId = _currentSessionId;
    bool sessionCreatedNow = false;

    if (currentSessionId == null || currentSessionId.isEmpty) {
      print("Creating new session...");
      String? topic = await _getTopicFromGemini(userMessage);
      if (topic != null && topic.isNotEmpty) {
        currentSessionId = topic;
        if (mounted) setState(() => _currentSessionTopic = topic);
      } else {
        currentSessionId = _uuid.v4();
        if (mounted) setState(() => _currentSessionTopic = null);
      }
      sessionCreatedNow = true;
      if (mounted) setState(() => _currentSessionId = currentSessionId);
       // Ensure chat session is started for the new ID
       if(mounted && _model != null) {
          setState(() {
              // Start new session, potentially clear history depending on desired behavior
               _chatHistoryForAI.clear(); // Start fresh history for new session
               _chatHistoryForAI.add(Content("model",[TextPart("Hello! How can I help you?")])); // Add initial prompt back if needed
               _chatSession = _model!.startChat(history: _chatHistoryForAI); // Start with potentially empty history
               print("New chat session started for ID: $currentSessionId");
          });
       }
    }

    // Save user message & add to AI history *before* calling API
    if (currentSessionId != null && currentSessionId.isNotEmpty) {
       await _saveMessageToDatabase("user", userMessage, currentSessionId);
       // Manually add user message to history if _chatSession doesn't handle it automatically on send
        // _chatHistoryForAI.add(Content("user", [Part.text(userMessage)])); // May not be needed if _chatSession manages history
    } else {
       print("CRITICAL ERROR: Session ID null after generation attempt.");
       _addErrorMessageToChat("Critical Error: Could not establish chat session.");
       if (mounted) setState(() => _isLoading = false);
       return;
    }

    if (sessionCreatedNow) {
        await _loadChatSessionsForSidebar(); // Refresh sidebar
    }

    // Get bot response (handles its own state updates for streaming)
    await _getChatbotResponse(userMessage);

    // Final cleanup
    if (mounted) {
      setState(() => _isLoading = false);
    }
  }

  // --- UI Building Methods ---

  AppBar _buildAppBar() {
     return AppBar(
       title: const Text("Answerhub on m2s Q&A"),
       centerTitle: true, // Ensures title is centered
       leading: MediaQuery.of(context).size.width < 700
           ? IconButton(
               icon: const Icon(Icons.menu),
               tooltip: "Toggle History",
               // Prevent opening drawer if AI is thinking or session is loading
               onPressed: _isLoading ? null : () => _scaffoldKey.currentState?.openDrawer(),
             )
           : null, // No hamburger on large screens
     );
   }

   Widget _buildSidebarContent() {
     final bool isSessionLoadingError = _chatSessionsForSidebar.isNotEmpty && _chatSessionsForSidebar.first.containsKey('error');
     final theme = Theme.of(context);

     return SafeArea( // Ensure content avoids notches/status bars within Drawer
       child: Container(
         // Use theme color for consistency
          color: theme.colorScheme.surface, // Drawer background
          child: Column(
            children: [
               Padding(
                 padding: const EdgeInsets.fromLTRB(12.0, 16.0, 12.0, 8.0), // More top padding
                 child: ElevatedButton.icon(
                   icon: const Icon(Icons.add_circle_outline),
                   label: const Text("New Chat"),
                   style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(45)), // Taller button
                   onPressed: _isLoading ? null : _createNewChat,
                 ),
               ),
               Padding(
                 padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
                 child: Text( "Chat History", style: theme.textTheme.titleMedium), // Use theme text style
               ),
               const Divider(height: 1, thickness: 1),
               Expanded(
                 child: isSessionLoadingError
                   ? Center(child: Text(_chatSessionsForSidebar.first['error'], style: TextStyle(color: Colors.redAccent[100])))
                   : _chatSessionsForSidebar.isEmpty
                      ? const Center(child: Text("No chat history yet", style: TextStyle(color: Colors.grey)))
                      : ListView.builder(
                         itemCount: _chatSessionsForSidebar.length,
                         itemBuilder: (context, index) {
                           final session = _chatSessionsForSidebar[index];
                           final sessionId = session['session_id'] as String;
                           final displayLength = MediaQuery.of(context).size.width > 400 ? 27 : 18;
                           final displayText = sessionId.length > displayLength ? '${sessionId.substring(0, displayLength)}...' : sessionId;
                           final isCurrent = sessionId == _currentSessionId;

                           return Padding(
                             padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 3.0), // Adjust spacing
                             child: ElevatedButton(
                               style: ElevatedButton.styleFrom(
                                 backgroundColor: isCurrent ? theme.primaryColor.withOpacity(0.4) : theme.colorScheme.surfaceVariant.withOpacity(0.6),
                                 foregroundColor: theme.colorScheme.onSurface,
                                 shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                                 padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                                 minimumSize: const Size.fromHeight(40),
                               ),
                               onPressed: _isLoading ? null : () => _loadChatSession(sessionId),
                               child: Align(
                                 alignment: Alignment.centerLeft,
                                 child: Tooltip(
                                    message: "Load: $sessionId",
                                    child: Text(displayText, overflow: TextOverflow.ellipsis),
                                 ),
                               ),
                             ),
                           );
                         },
                      ),
               ),
               const Divider(height: 1, thickness: 1),
               Padding(
                 padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
                 child: TextButton.icon( // Use TextButton for less emphasis
                   icon: Icon(Icons.delete_sweep_outlined, color: Colors.redAccent[100]),
                   label: Text("Clear History", style: TextStyle(color: Colors.redAccent[100])),
                   style: TextButton.styleFrom(minimumSize: const Size.fromHeight(40)),
                   onPressed: _isLoading ? null : _clearChatHistory,
                 ),
               ),
               const Divider(height: 1, thickness: 1),
               Padding(
                 padding: const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 12.0), // Adjust padding
                 child: TextButton.icon( // Use TextButton
                   icon: const Icon(Icons.info_outline),
                   label: const Text("Learn more.."),
                    style: TextButton.styleFrom(minimumSize: const Size.fromHeight(40)),
                   onPressed: () async {
                      final url = Uri.parse("https://meet2share.com/");
                       if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
                          _showSnackbar("Could not open link");
                       }
                   },
                 ),
               ),
            ],
          ),
       ),
     );
   }

   Widget _buildTextInputArea() {
    return Padding(
      padding: EdgeInsets.only(
          left: 8.0,
          right: 8.0,
          bottom: MediaQuery.of(context).padding.bottom + 8.0, // Adjust for keyboard/notch
          top: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: TextField(
              controller: _textController,
              minLines: 1,
              maxLines: 5,
              textCapitalization: TextCapitalization.sentences,
              style: const TextStyle(fontSize: 16),
              decoration: const InputDecoration( // Use theme defaults via main.dart
                hintText: "Type your message...",
                isDense: true,
              ),
              // Send on keyboard action only if not loading
              onSubmitted: _isLoading ? null : (_) => _sendMessage(),
              textInputAction: TextInputAction.send,
              enabled: !_isLoading,
            ),
          ),
          const SizedBox(width: 8),
          IconButton.filled(
            icon: const Icon(Icons.send),
            tooltip: "Send Message",
            iconSize: 24,
            onPressed: _isLoading ? null : _sendMessage,
             // Style comes from theme, but can override padding
             padding: const EdgeInsets.all(12),
          ),
        ],
      ),
    );
  }

  // --- Main Build Method ---
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final bool isLargeScreen = screenWidth >= 700;

    // Chat Area Widget Definition
     Widget chatList = ListView.builder(
         controller: _chatScrollController,
         padding: const EdgeInsets.only(top: 8.0, bottom: 8.0), // Add padding top/bottom
         itemCount: _currentChatMessages.length,
         reverse: false, // Keep newest messages at the bottom
         itemBuilder: (context, index) {
            // Removed loading indicator from here
            if (index >= _currentChatMessages.length) return const SizedBox.shrink();
            final message = _currentChatMessages[index];
            // Use index as key, or a unique message ID if available
            return ChatMessageWidget(
               key: ValueKey("msg_$index"), // Example key
               text: message.text,
               isUser: message.isUser,
            );
         },
       );

     Widget chatArea = Column(
       children: [
         Expanded(
           child: GestureDetector(
             onTap: () => FocusScope.of(context).unfocus(),
             child: chatList, // Use the defined ListView
           ),
         ),
         // Loading indicator shown between list and input
          if (_isLoading)
             const Padding(
                padding: EdgeInsets.symmetric(vertical: 4.0, horizontal: 16.0),
                child: LinearProgressIndicator(minHeight: 2), // Thin indicator
             ),
         // Divider removed as input area now has its own border/bg
         _buildTextInputArea(),
       ],
     );

    return Scaffold(
      key: _scaffoldKey,
      appBar: _buildAppBar(),
      // Use Drawer for small screens
      drawer: isLargeScreen ? null : Drawer(child: _buildSidebarContent()),
      body: Row(
        children: [
          // Fixed sidebar panel for large screens
          if (isLargeScreen)
              SizedBox(
                width: 260, // Slightly wider fixed sidebar
                child: Column(
                   children: [
                      Expanded(child: _buildSidebarContent()),
                      // Optional: Add footer/status in sidebar here
                   ],
                ),
              ),
          if (isLargeScreen) const VerticalDivider(width: 1, thickness: 1),
          // Main chat content area
          Expanded(
            child: chatArea,
          ),
        ],
      ),
    );
  }

  // --- Helper Methods ---
   void _scrollToBottom({int delay = 0}) {
     // Debounce or delay scrolling slightly to allow layout to settle
     Timer(Duration(milliseconds: delay > 50 ? delay : 50), () {
        if (_chatScrollController.hasClients) {
          _chatScrollController.animateTo(
            _chatScrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), // Faster scroll
            curve: Curves.easeOutQuad, // Smoother curve
          );
        }
     });
   }

  //  void _showSnackbar(String message, {bool isError = false, Duration duration = const Duration(seconds: 3)}) {
  //    if (!mounted) return;
  //    ScaffoldMessenger.of(context).removeCurrentSnackBar();
  //    ScaffoldMessenger.of(context).showSnackBar(
  //      SnackBar(
  //        content: Text(message),
  //        backgroundColor: isError ? Colors.redAccent[100] : Colors.green[700],
  //        behavior: SnackBarBehavior.floating,
  //        duration: duration,
  //        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)), // Rounded snackbar
  //        margin: const EdgeInsets.all(10), // Add margin
  //      ),
  //    );
  //  }

} // End _ChatScreenState