import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // For Clipboard
import 'package:flutter_markdown/flutter_markdown.dart'; // For Markdown
import 'package:url_launcher/url_launcher.dart'; // For launching URLs

class ChatMessageWidget extends StatelessWidget {
  final String text;
  final bool isUser;
  // copyCallback is removed as copy logic is self-contained now

  const ChatMessageWidget({
    super.key, // Flutter's Key system
    required this.text,
    required this.isUser,
  });

  // Helper to launch URL safely
  Future<void> _launchUrl(String url, BuildContext context) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      // Show feedback if launching fails
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Could not launch $url'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
      print('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final Color messageBgColor = isUser
        ? theme.colorScheme.primaryContainer.withOpacity(0.5) // User message background
        : theme.colorScheme.surfaceVariant; // Model message background
    final Color textColor = isUser
        ? theme.colorScheme.onPrimaryContainer
        : theme.colorScheme.onSurfaceVariant; // Adjust text color based on bg

    // Build the markdown content
    final markdownContent = MarkdownBody(
      data: text,
      selectable: true,
      // Style the markdown elements
      styleSheet: MarkdownStyleSheet.fromTheme(theme).copyWith(
        p: theme.textTheme.bodyMedium?.copyWith(color: textColor),
        code: theme.textTheme.bodyMedium?.copyWith(
          backgroundColor: theme.colorScheme.onSurface.withOpacity(0.1),
          color: theme.colorScheme.secondary, // Use accent color for code
          fontFamily: 'monospace', // Use a monospace font for code
        ),
        // Add styling for other elements like blockquotes, headers, lists etc.
        blockquoteDecoration: BoxDecoration(
          color: theme.colorScheme.onSurface.withOpacity(0.05),
          border: Border(left: BorderSide(color: theme.dividerColor, width: 4)),
        ),
         h1: theme.textTheme.titleLarge?.copyWith(color: textColor),
         h2: theme.textTheme.titleMedium?.copyWith(color: textColor),
         // Ensure link color is distinct
         a: TextStyle(color: Colors.lightBlueAccent[100], decoration: TextDecoration.underline, decorationColor: Colors.lightBlueAccent[100]),
      ),
      onTapLink: (text, href, title) {
        if (href != null) {
          _launchUrl(href, context);
        }
      },
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch, // Make column fill width
      children: [
        const Divider(color: Colors.white12, height: 1, thickness: 1),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 4.0), // Add vertical spacing
          child: Row(
           crossAxisAlignment: CrossAxisAlignment.start, // Align items top
            children: [
              Expanded(
                child: Container(
                   margin: isUser
                       ? const EdgeInsets.only(left: 40.0, right: 8.0) // Indent user messages
                       : const EdgeInsets.only(right: 40.0, left: 8.0), // Indent bot messages
                   padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                   decoration: BoxDecoration(
                     color: messageBgColor,
                     borderRadius: BorderRadius.circular(12), // Rounded corners
                   ),
                   child: markdownContent,
                 ),
              ),
              // Keep copy button compact and aligned
              Padding(
                padding: const EdgeInsets.only(top: 4.0, right: 4.0, left: 4.0), // Padding around button
                child: IconButton(
                  icon: const Icon(Icons.copy_outlined), // Use outlined icon
                  tooltip: "Copy",
                  iconSize: 18,
                  splashRadius: 20,
                  visualDensity: VisualDensity.compact,
                  color: theme.iconTheme.color?.withOpacity(0.7), // Subtle icon color
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: text));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Copied to clipboard'),
                        duration: Duration(seconds: 1),
                        behavior: SnackBarBehavior.floating, // Make snackbar float
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}