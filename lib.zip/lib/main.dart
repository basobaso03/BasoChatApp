import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // <-- Import this
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'screens/chat_screen.dart'; // Your main chat screen file

import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'dart:io'; // To check platform

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
    print("--- DEBUG: Sqflite FFI initialized for Desktop.");
  }


  // --- Debug Step: Try loading the asset directly ---
  try {
    print("--- DEBUG: Attempting to load '.env' via rootBundle...");
    final String envContent = await rootBundle.loadString('.env');
    print("--- DEBUG: Successfully loaded '.env' via rootBundle. Length: ${envContent.length}");
  } catch (e) {
    print("--- DEBUG: ERROR loading '.env' via rootBundle: $e");
  }
  // --- End Debug Step ---

  // ... rest of your main function (dotenv.load, runApp) ...
  // Load environment variables from the .env file
  print("--- DEBUG: Attempting dotenv.load()..."); // Add print before
  try {
    await dotenv.load(fileName: ".env");
    print("--- DEBUG: dotenv.load() completed successfully."); // Add print after
    // Verify if the key is accessible *after* loading
    final keyCheck = dotenv.env['GEMINI_API_KEY'];
    print("--- DEBUG: GEMINI_API_KEY after load: ${keyCheck != null && keyCheck.isNotEmpty ? 'Found' : 'NOT FOUND or empty'}");
  } catch(e) {
     print("--- DEBUG: ERROR during dotenv.load(): $e"); // Catch error here too
  }
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Answerhub on m2s Q&A',
      debugShowCheckedModeBanner: false, // Hide debug banner
      theme: ThemeData(
        // Use a dark theme as a base, similar to the Flet example
        brightness: Brightness.dark,
        primarySwatch: Colors.blueGrey, // Base color swatch
        scaffoldBackgroundColor: Colors.grey[900], // Dark background
        colorScheme: ColorScheme.dark(
          primary: Colors.blueGrey[300]!, // Primary color for buttons, etc.
          secondary: Colors.tealAccent[400]!, // Accent color
          surface: Colors.grey[850]!, // Card/dialog surfaces
          surfaceVariant: Colors.blueGrey[700]?.withOpacity(0.8), // Input field background
          onPrimary: Colors.black87, // Text/icons on primary color
          onSurface: Colors.white, // Default text color
        ),
        // Customize App Bar theme
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.blueGrey[900],
          foregroundColor: Colors.white, // Title text color
          elevation: 1.0,
        ),
        // Customize Text Field theme
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.blueGrey[700]?.withOpacity(0.8),
          hintStyle: TextStyle(color: Colors.grey[400]),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(25.0),
            borderSide: BorderSide.none,
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        ),
        // Customize Button themes if needed
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blueGrey[600]?.withOpacity(0.8),
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
        ),
        // Ensure IconButton themes are consistent
         iconButtonTheme: IconButtonThemeData(
           style: IconButton.styleFrom(
             foregroundColor: Colors.blueGrey[200]
           )
         ),
         tooltipTheme: TooltipThemeData(
           waitDuration: const Duration(milliseconds: 500), // Show tooltips faster
           textStyle: TextStyle(fontSize: 12, color: Colors.black87),
           decoration: BoxDecoration(
             color: Colors.blueGrey[200],
             borderRadius: BorderRadius.circular(4),
           ),
         ),
      ),
      home: const ChatScreen(), // Start with the chat screen
    );
  }
}

