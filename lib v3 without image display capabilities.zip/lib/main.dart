import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // For rootBundle
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'screens/chat_screen.dart'; // Your main chat screen file

import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'dart:io'; // To check platform

import 'dart:io' show Platform; // To check the platform


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize sqflite_common_ffi for desktop platforms
  if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
    print("--- DEBUG: Sqflite FFI initialized for Desktop.");
  }


  // --- Debug Step: Try loading the asset directly ---
  // This helps confirm the .env file is included in the build assets
  try {
    print("--- DEBUG: Attempting to load '.env' via rootBundle...");
    final String envContent = await rootBundle.loadString('.env');
    print("--- DEBUG: Successfully loaded '.env' via rootBundle. Length: ${envContent.isNotEmpty ? envContent.length : 'EMPTY'}");
    if (envContent.isEmpty) {
       print("--- DEBUG: WARNING - .env file loaded but is empty!");
    }
  } catch (e) {
    print("--- DEBUG: ERROR loading '.env' via rootBundle: $e. Ensure '.env' is in the project root and listed in pubspec.yaml assets.");
  }
  // --- End Debug Step ---


  // Load environment variables from the .env file
  print("--- DEBUG: Attempting dotenv.load()...");
  try {
    // Ensure the filename matches exactly (case-sensitive on some systems)
    await dotenv.load(fileName: ".env");
    print("--- DEBUG: dotenv.load() completed successfully.");
    // Verify if the key is accessible *after* loading
    final keyCheck = dotenv.env['GEMINI_API_KEY'];
    print("--- DEBUG: GEMINI_API_KEY after load: ${keyCheck != null && keyCheck.isNotEmpty ? 'Found (${keyCheck.substring(0, 4)}...)' : 'NOT FOUND or empty'}");
     if (keyCheck == null || keyCheck.isEmpty) {
       print("--- DEBUG: CRITICAL - GEMINI_API_KEY is missing or empty in the loaded environment variables. Check the .env file content and ensure it was loaded correctly.");
     }
  } catch(e) {
     print("--- DEBUG: ERROR during dotenv.load(): $e. Check if the file exists and is accessible.");
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Answerhub on m2s Q&A',
      debugShowCheckedModeBanner: false, // Hide debug banner
      theme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.blueGrey,
        scaffoldBackgroundColor: Colors.grey[900],
        colorScheme: ColorScheme.dark(
          primary: Colors.blueGrey[300]!,
          secondary: Colors.tealAccent[400]!,
          surface: Colors.grey[850]!,
          surfaceVariant: Colors.blueGrey[700]?.withOpacity(0.8),
          onPrimary: Colors.black87,
          onSurface: Colors.white,
          // Added for the copy bar background
          secondaryContainer: Colors.blueGrey[700],
          onSecondaryContainer: Colors.white70,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.blueGrey[900],
          foregroundColor: Colors.white,
          elevation: 1.0,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.blueGrey[700]?.withOpacity(0.8),
          hintStyle: TextStyle(color: Colors.grey[400]),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(25.0),
            borderSide: BorderSide.none,
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          // Style for disabled state (e.g., when offline or copying)
          disabledBorder: OutlineInputBorder(
             borderRadius: BorderRadius.circular(25.0),
             borderSide: BorderSide(color: Colors.grey[600]!), // Subtle border when disabled
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blueGrey[600]?.withOpacity(0.8),
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
        ),
         iconButtonTheme: IconButtonThemeData(
           style: IconButton.styleFrom(
             foregroundColor: Colors.blueGrey[200]
           )
         ),
         tooltipTheme: TooltipThemeData(
           waitDuration: const Duration(milliseconds: 500),
           textStyle: const TextStyle(fontSize: 12, color: Colors.black87),
           decoration: BoxDecoration(
             color: Colors.blueGrey[200],
             borderRadius: BorderRadius.circular(4),
           ),
         ),
         // Style for the offline indicator bar
         bannerTheme: MaterialBannerThemeData(
            backgroundColor: Colors.orange[800],
            contentTextStyle: const TextStyle(color: Colors.white, fontSize: 12),
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
         ),
      ),
      home: const ChatScreen(), // Start with the chat screen
    );
  }
}
