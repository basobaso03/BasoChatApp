import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart'; // For Markdown rendering
import 'package:url_launcher/url_launcher.dart'; // For launching URLs in Markdown

class ChatMessageWidget extends StatelessWidget {
  final String text;
  final bool isUser;
  final int index; // Index of the message in the list
  final bool isSelected; // Whether the message is currently selected (for copy)
  // Callbacks passed from chat_screen.dart
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;

  const ChatMessageWidget({
    super.key,
    required this.text,
    required this.isUser,
    required this.index,
    required this.isSelected,
    this.onTap, // Callback for tapping the message bubble
    this.onLongPress, // Callback for long-pressing the message bubble
  });

  // Helper function to safely launch URLs found in Markdown
  Future<void> _launchUrl(String url, BuildContext context) async {
    final Uri uri = Uri.parse(url);
    // Check if the URL can be launched before attempting
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      // Show an error message if launching fails
      if (context.mounted) { // Check if the widget is still in the tree
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Could not launch $url'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
      print('Could not launch $url');
    }
  }

    @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final screenWidth = MediaQuery.of(context).size.width;

    // --- Define Colors based on Theme and State ---
    final Color regularBgColor = isUser
        ? theme.colorScheme.primaryContainer.withOpacity(0.5) // User message background
        : theme.colorScheme.surfaceVariant ?? Colors.grey.shade700; // Bot message background (with fallback)
    final Color selectedBgColor = isUser
        ? theme.colorScheme.primaryContainer // User selected background (more opaque)
        : (theme.colorScheme.surfaceVariant ?? Colors.grey.shade700)
            .withOpacity(0.9); // Bot selected background (slightly darker/more opaque)

    final Color currentBgColor = isSelected ? selectedBgColor : regularBgColor;

    // Determine text color based on user type for contrast
    final Color textColor = isUser
        ? theme.colorScheme.onPrimaryContainer
        : theme.colorScheme.onSurfaceVariant;

    // --- Prepare Markdown Content ---
    final markdownContent = MarkdownBody(
      data: text, // The message text
      selectable: true, // Allow users to select text within the bubble
      styleSheet: MarkdownStyleSheet.fromTheme(theme).copyWith(
        p: theme.textTheme.bodyMedium?.copyWith(color: textColor), // Paragraph style
        code: theme.textTheme.bodyMedium?.copyWith( // Code block style
          backgroundColor: theme.colorScheme.onSurface.withOpacity(0.1),
          color: theme.colorScheme.secondary, // Use secondary color for code text
          fontFamily: 'monospace', // Use a monospace font
        ),
        blockquoteDecoration: BoxDecoration( // Blockquote style
          color: theme.colorScheme.onSurface.withOpacity(0.05),
          border: Border(left: BorderSide(color: theme.dividerColor, width: 4)),
        ),
        h1: theme.textTheme.titleLarge?.copyWith(color: textColor), // Heading styles
        h2: theme.textTheme.titleMedium?.copyWith(color: textColor),
        a: TextStyle( // Link style
            color: Colors.lightBlueAccent[100], // Distinct link color
            decoration: TextDecoration.underline,
            decorationColor: Colors.lightBlueAccent[100]),
      ),
      onTapLink: (text, href, title) {
        if (href != null) {
          _launchUrl(href, context); // Launch the URL using the helper function
        }
      },
    );

    // --- Layout Implementation (Shrink-to-fit with Flexible fix) ---
    return Padding(
      padding: EdgeInsets.symmetric(
          vertical: isSelected ? 6.0 : 4.0,
          horizontal: 8.0
      ),
      child: Row(
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Flexible(
            child: GestureDetector(
              onTap: onTap,
              onLongPress: onLongPress,
              child: Container(
                constraints: BoxConstraints(
                  maxWidth: isUser
                      ? screenWidth * 0.75
                      : screenWidth * 0.85
                ),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration( // <<< BoxDecoration starts here
                  color: currentBgColor,
                  // --- MODIFIED BorderRadius ---
                  borderRadius: BorderRadius.only(
                    topLeft: const Radius.circular(18.0), // More rounded
                    topRight: const Radius.circular(18.0), // More rounded
                    bottomLeft: isUser ? const Radius.circular(18.0) : const Radius.circular(0), // Sharp for bot tail
                    bottomRight: isUser ? const Radius.circular(0) : const Radius.circular(18.0), // Sharp for user tail
                  ),
                  // --- End MODIFIED BorderRadius ---
                  border: isSelected
                      ? Border.all(color: theme.highlightColor.withOpacity(0.6), width: 1.5)
                      : null,
                ), // <<< BoxDecoration ends here
                child: markdownContent,
              ),
            ),
          ),
        ],
      ),
    );
  } // End build method
}
