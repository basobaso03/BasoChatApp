import 'dart:async'; // For Timer (throttling) and async
import 'dart:io'; // For File operations
import 'dart:typed_data'; // For Uint8List (file bytes)

import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // For Clipboard
import 'package:google_generative_ai/google_generative_ai.dart'; // Gemini AI
import 'package:sqflite/sqflite.dart'; // SQLite
import 'package:path/path.dart' as p; // Path manipulation
import 'package:path_provider/path_provider.dart'; // For getting app directories
import 'package:uuid/uuid.dart'; // UUID generation
import 'package:flutter_dotenv/flutter_dotenv.dart'; // For API Key
import 'package:url_launcher/url_launcher.dart'; // For About Us link
import 'package:connectivity_plus/connectivity_plus.dart'; // For connectivity
import 'package:file_picker/file_picker.dart'; // For picking files
import 'package:permission_handler/permission_handler.dart'; // For permissions
import 'package:speech_to_text/speech_to_text.dart'; // For speech-to-text
import 'package:speech_to_text/speech_recognition_error.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:mime/mime.dart'; // For determining MIME types

// Import the message widget (adjust path if necessary)
// Ensure you have a ChatMessageWidget defined in this path
import '../widgets/chat_message_widget.dart';

// Data structure for chat messages displayed in the UI
class AppChatMessage {
  final String text;
  final bool isUser;
  // final String id; // Optional unique ID if needed for keys/diffing

  AppChatMessage({required this.text, required this.isUser /*, required this.id */});

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AppChatMessage &&
          runtimeType == other.runtimeType &&
          text == other.text &&
          isUser == other.isUser;

  @override
  int get hashCode => text.hashCode ^ isUser.hashCode;
}

// Data structure for attachments (used in state and DB interaction)
class AppAttachment {
  final String id; // Unique ID for this attachment record (used as PK in DB)
  final String originalName;
  final String storedPath; // Full path where the file is stored locally
  final String? mimeType; // Detected MIME type (e.g., 'application/pdf')

  AppAttachment({
    required this.id,
    required this.originalName,
    required this.storedPath,
    this.mimeType,
  });

  // Convert to Map for database storage
  Map<String, dynamic> toMap(String sessionId, int timestamp) {
    return {
      'id': id,
      'session_id': sessionId,
      'original_name': originalName,
      'stored_path': storedPath,
      'mime_type': mimeType,
      'timestamp': timestamp,
    };
  }

  // Create from Map (retrieved from database)
  factory AppAttachment.fromMap(Map<String, dynamic> map) {
    return AppAttachment(
      id: map['id'] as String,
      originalName: map['original_name'] as String,
      storedPath: map['stored_path'] as String,
      mimeType: map['mime_type'] as String?,
      // session_id and timestamp are part of the DB row but not needed in the state object itself
    );
  }
}


class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with WidgetsBindingObserver {
  // --- State Variables ---
  GenerativeModel? _model;
  ChatSession? _chatSession;
  Database? _database;
  final Uuid _uuid = const Uuid();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final ScrollController _chatScrollController = ScrollController();
  final TextEditingController _textController = TextEditingController();
  bool _isLoading = false; // General loading state (API calls, file processing)

  // UI Chat message list
  final List<AppChatMessage> _currentChatMessages = [];
  // History for the AI model (includes text and potentially data parts)
  List<Content> _chatHistoryForAI = [];
  String? _currentSessionId; // ID of the currently active chat session
  String? _currentSessionTopic; // Display topic for the current session
  List<Map<String, dynamic>> _chatSessionsForSidebar = []; // List of sessions for the drawer/sidebar

  // Prompt used to ask Gemini for a chat topic based on the first message
  final String _topicModelingPrompt = "Determine the shortest phrase which I can use as a topic for the provided question. Do not add any additional words, comments, explanations, symbols, or punctuation. question: ";

  // Throttling for scroll-to-bottom to avoid excessive calls
  Timer? _updateThrottleTimer;
  final Duration _throttleDuration = const Duration(milliseconds: 100);

  // State for message selection (copy functionality)
  String? _selectedMessageTextForCopy;
  int? _selectedMessageIndex;

  // Connectivity state
  bool _isOffline = false;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySubscription;
  AppChatMessage? _lastUserMessagePendingSend; // Simple buffer for one pending message

  // --- State Variables for New Features ---
  List<AppAttachment> _currentAttachments = []; // Holds currently attached files for the session
  final SpeechToText _speechToText = SpeechToText(); // Speech recognition instance
  bool _speechEnabled = false; // Is speech recognition available and initialized?
  bool _isListening = false; // Is the app currently recording audio?
  String _lastRecognizedWords = ""; // Buffer for recognized speech
  bool _showRecordingIndicator = false; // Controls visibility of the AppBar recording indicator

  // --- Initialization and Lifecycle ---

  @override
  void initState() {
    super.initState();
    print("initState: Starting ChatScreen initialization...");
    WidgetsBinding.instance.addObserver(this); // Observe app lifecycle changes
    _initializeModel(); // Set up Gemini model connection
    _requestPermissions(); // Request necessary permissions (mic) proactively
    _initSpeech(); // Initialize the speech-to-text engine
    _initializeDatabaseAndLoadChat(); // Initialize SQLite DB and load initial chat state
    _initializeConnectivityListener(); // Start listening for network changes
    print("initState: Initialization sequence started.");
  }

  // Combined async initialization for DB and initial chat load
  Future<void> _initializeDatabaseAndLoadChat() async {
    print("Initializing database...");
    await _initializeDatabase();
    if (mounted) { // Check if the widget is still in the tree
      print("Database initialized. Loading last session or setting up new chat...");
      await _loadLastSessionOrSetupNew();
      print("Chat loaded/setup complete.");
    } else {
      print("Widget unmounted during database initialization.");
    }
  }

  // Set up the connection to the Gemini API
  void _initializeModel() {
    print("Initializing Generative Model...");
    final apiKey = dotenv.env['GEMINI_API_KEY'];
    if (apiKey == null || apiKey.isEmpty) {
      print('CRITICAL ERROR: GEMINI_API_KEY not found or empty in .env file.');
      // Add error message directly to chat if UI is ready, otherwise it might be lost
      WidgetsBinding.instance.addPostFrameCallback((_) {
         if (mounted) _addErrorMessageToChat("Configuration Error: Could not initialize AI. API Key is missing.");
      });
      return;
    }
    try {
      _model = GenerativeModel(
        model: 'gemini-2.0-flash', // Specify the model to use
        apiKey: apiKey,
        // Optional: Configure safety settings for generated content
        // safetySettings: [
        //   SafetySetting(HarmCategory.harassment, HarmBlockThreshold.medium),
        //   SafetySetting(HarmCategory.hateSpeech, HarmBlockThreshold.medium),
        //   // Add more categories as needed
        // ],
        // Optional: Configure generation parameters
        // generationConfig: GenerationConfig(
        //   temperature: 0.7,
        //   // Add other parameters like topP, topK, maxOutputTokens
        // )
      );
      print("Generative Model initialized successfully.");
    } catch (e) {
      print("Error initializing Generative Model: $e");
      WidgetsBinding.instance.addPostFrameCallback((_) {
         if (mounted) _addErrorMessageToChat("Initialization Error: Failed to set up AI model. $e");
      });
    }
  }

  // Set up listener for network connectivity changes
  void _initializeConnectivityListener() {
    print("Initializing connectivity listener...");
    _connectivitySubscription = Connectivity().onConnectivityChanged.listen((results) {
      _updateConnectionStatus(results);
    });
    // Check initial status
    Connectivity().checkConnectivity().then(_updateConnectionStatus);
    print("Connectivity listener initialized.");
  }

  // Request necessary permissions (Microphone for now)
  Future<void> _requestPermissions() async {
    print("Requesting permissions...");
    // Request Microphone permission
    var micStatus = await Permission.microphone.request();
    print("Microphone permission status: $micStatus");
    if (micStatus.isDenied) {
      // User denied, but can be asked again
      _showSnackbar("Microphone permission is needed for voice input.", duration: const Duration(seconds: 4), bgColor: Colors.orange[800]);
    } else if (micStatus.isPermanentlyDenied) {
      // User permanently denied, direct them to settings
       _showSnackbar("Microphone permission permanently denied. Please enable it in app settings.", duration: const Duration(seconds: 5), bgColor: Colors.redAccent);
       // Optionally open app settings: openAppSettings();
    }

    // Storage permissions note:
    // Modern Android/iOS handle storage access via scoped methods or implicitly through pickers.
    // Explicit broad storage permissions are usually not required unless targeting very old Android versions.
    // if (Platform.isAndroid) {
    //   // Example check for older Android if needed:
    //   // var storageStatus = await Permission.storage.request();
    // }
    print("Permission requests complete.");
  }

  // Initialize the SpeechToText engine
  Future<void> _initSpeech() async {
    print("Initializing SpeechToText...");
    try {
      // Initialize the plugin
      _speechEnabled = await _speechToText.initialize(
        onError: _speechErrorListener, // Callback for errors
        onStatus: _speechStatusListener, // Callback for status changes
        debugLogging: false, // Set to true for verbose STT logs
      );
      if (mounted) setState(() {}); // Update UI based on _speechEnabled status
      print("SpeechToText initialized. Enabled: $_speechEnabled");
    } catch (e) {
      print("Error initializing SpeechToText: $e");
      if (mounted) {
        _showSnackbar("Could not initialize voice input: $e", bgColor: Colors.redAccent);
        setState(() => _speechEnabled = false); // Ensure state reflects failure
      }
    }
  }

  @override
  void dispose() {
    print("Disposing ChatScreen State...");
    WidgetsBinding.instance.removeObserver(this); // Stop observing lifecycle
    _chatScrollController.dispose(); // Dispose scroll controller
    _textController.dispose(); // Dispose text editing controller
    _updateThrottleTimer?.cancel(); // Cancel any pending scroll timer
    _connectivitySubscription?.cancel(); // Cancel network listener
    _speechToText.cancel(); // Cancel any ongoing speech recognition
    // Closing the database here can cause issues if other operations are pending.
    // Sqflite generally manages the connection pool. Explicit closing is often not needed.
    // _database?.close();
    print("ChatScreen State disposed.");
    super.dispose();
  }

  // Handle app lifecycle changes (e.g., pause, resume)
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    print("App Lifecycle State Changed: $state");
    if (state == AppLifecycleState.resumed) {
      // Re-check connectivity when app resumes
      Connectivity().checkConnectivity().then(_updateConnectionStatus);
      // Optionally re-check permissions or re-initialize STT if it fails often
    } else if (state == AppLifecycleState.paused) {
       // Stop listening if the app is paused to release microphone
       if (_isListening) {
          print("App paused, cancelling speech recognition.");
          _stopListening(cancel: true); // Use cancel to discard partial results
       }
    }
  }

  // Required override for WidgetsBindingObserver, not used here
  @override
  void didChangeMetrics() {}


  // --- Database Operations ---

  // Initialize the SQLite database connection and create/upgrade tables
  Future<void> _initializeDatabase() async {
    try {
      final dbPath = await getDatabasesPath(); // Get platform-specific path
      final path = p.join(dbPath, 'chat_history.db'); // Define DB file name
      print("Database path: $path");

      _database = await openDatabase(
        path,
        version: 2, // <<< Increment this number when schema changes
        onCreate: (db, version) async {
          // Called only when the database is created for the first time
          print("Creating database tables (Version $version)...");
          await _createTablesV1(db); // Create initial tables (sessions, messages)
          await _createTablesV2(db); // Add new attachments table
        },
        onUpgrade: (db, oldVersion, newVersion) async {
           // Called when the version number increases
           print("Upgrading database from version $oldVersion to $newVersion...");
           if (oldVersion < 2) {
              // If upgrading from version 1, add the attachments table
              await _createTablesV2(db);
           }
           // Add more 'if (oldVersion < X)' blocks for future upgrades
        },
        onOpen: (db) {
          print("Database opened successfully.");
          // Enable foreign key constraints (recommended for data integrity)
          db.execute('PRAGMA foreign_keys = ON');
          print("Foreign key support enabled.");
        },
      );
    } catch (e) {
      print("Error initializing database: $e");
      if (mounted) {
        _addErrorMessageToChat("Database Error: Could not initialize storage. $e");
      }
    }
  }

  // Helper for initial table creation (Version 1)
  Future<void> _createTablesV1(Database db) async {
     print("Creating sessions table...");
     await db.execute('''
      CREATE TABLE sessions (
        id TEXT PRIMARY KEY,
        topic TEXT,
        last_updated INTEGER NOT NULL
      )
    ''');
     print("Creating messages table...");
     await db.execute('''
      CREATE TABLE messages (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL,
        is_user INTEGER NOT NULL, -- 1 for user, 0 for bot
        text TEXT NOT NULL,
        timestamp INTEGER NOT NULL,
        FOREIGN KEY (session_id) REFERENCES sessions (id) ON DELETE CASCADE -- Delete messages if session is deleted
      )
    ''');
  }

  // Helper for adding the attachments table (Version 2)
  Future<void> _createTablesV2(Database db) async {
     print("Creating session_attachments table...");
     await db.execute('''
        CREATE TABLE session_attachments (
          id TEXT PRIMARY KEY, -- Unique ID for the attachment record itself
          session_id TEXT NOT NULL,
          original_name TEXT NOT NULL,
          stored_path TEXT NOT NULL,
          mime_type TEXT, -- Store the detected MIME type
          timestamp INTEGER NOT NULL,
          FOREIGN KEY (session_id) REFERENCES sessions (id) ON DELETE CASCADE -- Delete attachments if session is deleted
        )
      ''');
     print("session_attachments table created.");
  }


  // Get the ID of the most recently updated session
  Future<String?> _getLastSessionId() async {
    if (_database == null) return null;
    try {
      final List<Map<String, dynamic>> maps = await _database!.query(
        'sessions',
        columns: ['id'],
        orderBy: 'last_updated DESC', // Order by most recent
        limit: 1, // Get only the top one
      );
      if (maps.isNotEmpty) {
        final id = maps.first['id'];
        return (id is String) ? id : null; // Ensure it's a string
      }
      return null; // No sessions found
    } catch (e) {
      print("Error getting last session ID: $e");
      return null;
    }
  }

  // Load all messages and attachments for a specific session ID
  Future<void> _loadMessagesForSession(String sessionId) async {
    if (_database == null) {
      if (mounted) _addErrorMessageToChat("Error: Cannot load chat, database unavailable.");
      return;
    }
    if (mounted) setState(() => _isLoading = true); // Show loading indicator

    try {
      print("Loading messages and attachments for session: $sessionId");
      // Use a transaction for atomic read (optional but good practice)
      await _database!.transaction((txn) async {
         // Load messages
         final messagesData = await txn.query(
           'messages', where: 'session_id = ?', whereArgs: [sessionId], orderBy: 'timestamp ASC',
         );
         // Load session info (topic)
         final sessionData = await txn.query(
           'sessions', where: 'id = ?', whereArgs: [sessionId], limit: 1,
         );
         // Load attachments associated with this session
         final attachmentsData = await txn.query(
           'session_attachments', where: 'session_id = ?', whereArgs: [sessionId], orderBy: 'timestamp ASC',
         );

         // Process loaded data
         final loadedMessages = <AppChatMessage>[];
         final loadedHistory = <Content>[]; // History for AI (text only for startChat)
         final loadedAttachments = <AppAttachment>[]; // Attachments for UI state

         for (var msgData in messagesData) {
           final text = msgData['text'] as String?;
           final isUserInt = msgData['is_user'] as int?;
           if (text == null || isUserInt == null) {
              print("Warning: Skipping invalid message data: $msgData");
              continue;
           }
           final isUser = isUserInt == 1;
           loadedMessages.add(AppChatMessage(text: text, isUser: isUser));
           // Rebuild AI history (only text parts for startChat)
           loadedHistory.add(Content(isUser ? "user" : "model", [TextPart(text)]));
         }

         // Populate attachments list from DB data
         for (var attData in attachmentsData) {
            try {
              loadedAttachments.add(AppAttachment.fromMap(attData));
            } catch (e) {
               print("Warning: Could not parse attachment data: $attData. Error: $e");
               // Skip corrupted attachment data
            }
         }
         print("Loaded ${loadedAttachments.length} attachments for session $sessionId.");

         // Update state only if the widget is still mounted
         if (mounted) {
           setState(() {
             // Clear previous state
             _currentChatMessages.clear();
             _chatHistoryForAI.clear();
             _currentAttachments.clear();

             // Add loaded data
             _currentChatMessages.addAll(loadedMessages);
             _chatHistoryForAI.addAll(loadedHistory);
             _currentAttachments.addAll(loadedAttachments);

             // Update session info
             _currentSessionId = sessionId;
             _currentSessionTopic = sessionData.isNotEmpty ? sessionData.first['topic'] as String? : 'Chat'; // Fallback topic

             // Re-initialize the AI chat session with the loaded history
             if (_model != null) {
               // Note: startChat history doesn't support DataParts. Attachments are sent with messages.
               _chatSession = _model!.startChat(history: _chatHistoryForAI.isNotEmpty ? _chatHistoryForAI : null);
               print("Chat session re-initialized ${ _chatHistoryForAI.isNotEmpty ? 'with history' : 'fresh'} for session $sessionId.");
             } else {
               _chatSession = null; // Model not ready
                print("Warning: Model not available when re-initializing chat session $sessionId.");
                _addErrorMessageToChat("Warning: AI Model unavailable. Cannot continue conversation.");
             }

             _isLoading = false; // Hide loading indicator
             _selectedMessageIndex = null; // Clear any message selection
             _selectedMessageTextForCopy = null;
             _isListening = false; // Ensure listening state is reset
             _showRecordingIndicator = false; // Ensure indicator is hidden
           });
           _scrollToBottom(delayMillis: 150); // Scroll after UI updates
           print("Messages & attachments loaded successfully for session $sessionId.");
         }
      }); // End transaction
    } catch (e) {
      print("Error loading messages/attachments for session $sessionId: $e");
      if (mounted) {
        _addErrorMessageToChat("Error loading chat history: $e");
        setState(() => _isLoading = false); // Ensure loading stops on error
      }
    }
  }

  // Save a single chat message (text) to the database
  Future<void> _saveMessageToDatabase(AppChatMessage message, String sessionId, int timestamp) async {
    if (_database == null || !_database!.isOpen) {
       print("Error saving message: Database is not open.");
       return;
    }
    try {
      final messageId = _uuid.v4(); // Generate unique ID for the message
      await _database!.insert(
        'messages',
        {
          'id': messageId,
          'session_id': sessionId,
          'is_user': message.isUser ? 1 : 0,
          'text': message.text,
          'timestamp': timestamp,
        },
        conflictAlgorithm: ConflictAlgorithm.replace, // Replace if ID somehow exists
      );
      // Update the session's last_updated timestamp
      await _database!.update(
        'sessions',
        {'last_updated': timestamp},
        where: 'id = ?',
        whereArgs: [sessionId],
      );
      print("Message saved to DB (Session: $sessionId, ID: $messageId, User: ${message.isUser})");
    } catch (e) {
      print("Error saving message to database: $e");
      // Optionally show error to user?
    }
  }

  // Save a list of attachment metadata to the database for a given session
  Future<void> _saveAttachmentsToDatabase(List<AppAttachment> attachments, String sessionId) async {
     if (_database == null || !_database!.isOpen || attachments.isEmpty) return;
     print("Saving ${attachments.length} attachments to DB for session $sessionId...");
     // Use a batch for efficiency when saving multiple attachments
     final batch = _database!.batch();
     final timestamp = DateTime.now().millisecondsSinceEpoch;

     for (final attachment in attachments) {
        batch.insert(
           'session_attachments',
           attachment.toMap(sessionId, timestamp), // Convert object to map for DB
           conflictAlgorithm: ConflictAlgorithm.replace, // Replace if ID exists (shouldn't happen with UUIDs)
        );
     }
     try {
        await batch.commit(noResult: true); // Commit the batch
        print("Attachments saved successfully to DB.");
     } catch (e) {
        print("Error saving attachments to database: $e");
        if (mounted) _addErrorMessageToChat("Error saving attachments: $e");
     }
  }

  // Clear all chat history (sessions, messages, attachments)
  Future<void> _clearChatHistory() async {
    // Don't show dialog if there's nothing to clear
    if (_chatSessionsForSidebar.isEmpty && _currentSessionId == null) {
       _setupInitialChatState(); // Just reset to initial state
       return;
    }

    // Show confirmation dialog
    final confirm = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('Clear All History?'),
        content: const Text('This will permanently delete all chat sessions and their messages/attachments. This action cannot be undone.'),
        actions: <Widget>[
          TextButton(
            child: const Text('Cancel'),
            onPressed: () => Navigator.of(context).pop(false), // Return false
          ),
          TextButton(
            style: TextButton.styleFrom(foregroundColor: Colors.redAccent),
            child: const Text('Clear All'),
            onPressed: () => Navigator.of(context).pop(true), // Return true
          ),
        ],
      ),
    );

    if (confirm == true) {
      if (_database == null || !_database!.isOpen) {
         if (mounted) _addErrorMessageToChat("Error: Database unavailable.");
         return;
      }
      print("Clearing all chat history...");
      try {
        // 1. Get paths of all stored attachment files
        final List<Map<String, dynamic>> allAttachments = await _database!.query('session_attachments', columns: ['stored_path']);

        // 2. Delete the files from storage
        for (var attData in allAttachments) {
           final path = attData['stored_path'] as String?;
           if (path != null) {
              try {
                 final file = File(path);
                 if (await file.exists()) {
                    await file.delete();
                    print("Deleted attachment file: $path");
                 }
              } catch (e) {
                 // Log error but continue, DB cleanup is more critical
                 print("Error deleting attachment file $path: $e");
              }
           }
        }

        // 3. Delete all sessions from the database.
        // Foreign key constraints with ON DELETE CASCADE will handle deleting
        // associated messages and session_attachments rows automatically.
        int count = await _database!.delete('sessions');
        print("$count sessions (and associated messages/attachments) deleted from database.");

        // 4. Reset UI state
        if (mounted) {
          _setupInitialChatState(); // Reset to the initial "Hello" message state
          await _loadChatSessionsForSidebar(); // Refresh the sidebar (should be empty)
          _showSnackbar("All chat sessions deleted.", duration: const Duration(seconds: 2));
        }
      } catch (e) {
        print("Error deleting all chat sessions: $e");
        if (mounted) _addErrorMessageToChat("Error deleting chats: $e");
      }
    }
  }

  // Delete a single chat session and its associated data
  Future<void> _deleteSingleSession(String sessionId, String topic) async {
     // Show confirmation dialog
     final confirmDelete = await showDialog<bool>(
        context: context,
        builder: (BuildContext context) => AlertDialog(
          title: const Text('Delete Chat?'),
          content: Text('Are you sure you want to delete the chat "$topic"? This cannot be undone.'),
          actions: [
            TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Cancel')),
            TextButton(
               style: TextButton.styleFrom(foregroundColor: Colors.redAccent),
               onPressed: () => Navigator.of(context).pop(true),
               child: const Text('Delete')
            ),
          ],
        ),
      );

      if (confirmDelete == true && _database != null && _database!.isOpen) {
         print("Deleting session $sessionId ('$topic')");
         try {
            // 1. Get paths of attachments for *this specific session*
            final List<Map<String, dynamic>> sessionAttachments = await _database!.query(
               'session_attachments',
               columns: ['stored_path'],
               where: 'session_id = ?',
               whereArgs: [sessionId],
            );

            // 2. Delete the associated files
            for (var attData in sessionAttachments) {
               final path = attData['stored_path'] as String?;
               if (path != null) {
                  try {
                     final file = File(path);
                     if (await file.exists()) {
                        await file.delete();
                        print("Deleted attachment file for session $sessionId: $path");
                     }
                  } catch (e) {
                     print("Error deleting attachment file $path for session $sessionId: $e");
                  }
               }
            }

            // 3. Delete the session from the database.
            // ON DELETE CASCADE handles messages and session_attachments rows.
            int count = await _database!.delete('sessions', where: 'id = ?', whereArgs: [sessionId]);
            print("Deleted $count session(s) with ID $sessionId from DB.");

            // 4. Update UI
            await _loadChatSessionsForSidebar(); // Refresh sidebar list
            if (sessionId == _currentSessionId) {
               // If the currently active chat was deleted, start a new one
               _createNewChat();
            }
            _showSnackbar("Chat '$topic' deleted.", duration: const Duration(seconds: 2));
         } catch (e) {
            print("Error deleting session $sessionId: $e");
            _addErrorMessageToChat("Error deleting chat '$topic': $e");
         }
      }
  }


  // Load the list of sessions for display in the sidebar/drawer
  Future<void> _loadChatSessionsForSidebar() async {
    if (_database == null || !_database!.isOpen) return;
    try {
      final List<Map<String, dynamic>> sessions = await _database!.query(
        'sessions',
        columns: ['id', 'topic', 'last_updated'],
        orderBy: 'last_updated DESC', // Show most recent first
      );
      if (mounted) {
        setState(() {
          // Filter out any potential null IDs just in case
          _chatSessionsForSidebar = sessions.where((s) => s['id'] != null).toList();
        });
        print("Loaded ${_chatSessionsForSidebar.length} valid sessions for sidebar.");
      }
    } catch (e) {
      print("Error loading chat sessions for sidebar: $e");
      // Optionally show error? Usually non-critical if sidebar fails to load.
    }
  }

  // --- Chat State Logic ---

  // Reset the chat screen to its initial state (new chat)
  void _setupInitialChatState() {
    print("Setting up initial chat state...");
    if (!mounted) return; // Avoid calling setState if widget is disposed

    setState(() {
       // Reset session identifiers
       _currentSessionId = null;
       _currentSessionTopic = null;

       // Clear message lists and attachments
       _currentChatMessages.clear();
       _chatHistoryForAI.clear();
       _currentAttachments.clear(); // <<< Crucial: Clear attachments for new chat

       // Add the initial greeting message from the bot
       const initialMessageText = "Hello! How can I help you today?";
       final initialBotMessage = AppChatMessage(text: initialMessageText, isUser: false);
       _currentChatMessages.add(initialBotMessage);

       // Initialize AI history and session if model is ready
       if (_model != null) {
         // Add bot's greeting to AI history
         _chatHistoryForAI.add(Content("model", [TextPart(initialMessageText)]));
         // Start a new chat session with the AI
         _chatSession = _model!.startChat(history: _chatHistoryForAI);
         print("Initial chat session started with greeting.");
       } else {
          _chatSession = null; // Model not ready
          print("Initial chat state setup without active AI session (model not ready).");
          // Optionally add a warning message?
          // _currentChatMessages.add(AppChatMessage(text: "⚠️ AI model not available.", isUser: false));
       }

       // Reset UI states
       _isLoading = false;
       _selectedMessageTextForCopy = null;
       _selectedMessageIndex = null;
       _lastUserMessagePendingSend = null;
       _isListening = false; // Ensure listening state is reset
       _showRecordingIndicator = false; // Ensure indicator is hidden
       _textController.clear(); // Clear text input field
    });
    print("Initial chat state setup complete.");
    _scrollToBottom(); // Scroll down after setup
  }

  // Load the most recent chat session or start a new one if none exist
  Future<void> _loadLastSessionOrSetupNew() async {
     final lastSessionId = await _getLastSessionId();
     if (lastSessionId != null) {
       print("Loading last session: $lastSessionId");
       await _loadMessagesForSession(lastSessionId); // This now loads attachments too
       // If loading failed or session was empty, start fresh
       if (_currentChatMessages.isEmpty && mounted) {
           print("Warning: Session $lastSessionId loaded empty or failed to load. Starting new chat.");
           _setupInitialChatState();
       }
     } else {
       // No sessions found in the database
       print("No previous sessions found. Setting up initial chat.");
       if (mounted) _setupInitialChatState();
     }
     // Ensure UI elements like selection/listening state are reset after loading/setup
     if (mounted) {
       setState(() {
         _selectedMessageIndex = null;
         _selectedMessageTextForCopy = null;
         _isListening = false;
         _showRecordingIndicator = false;
       });
     }
     // Load all sessions for the sidebar regardless
     await _loadChatSessionsForSidebar();
  }

  // Load a specific chat session when clicked in the sidebar
  Future<void> _loadChatSession(String sessionId) async {
    print("Loading clicked session: $sessionId");
    // Avoid reloading if already loaded or currently loading
    if (sessionId == _currentSessionId || _isLoading) {
       // Close drawer if open on small screens
       if (MediaQuery.of(context).size.width < 700 && (_scaffoldKey.currentState?.isDrawerOpen ?? false)) {
          Navigator.of(context).pop();
       }
       print("Session already loaded or currently loading. Aborting load.");
      return;
    }

     if (mounted) setState(() => _isLoading = true); // Show loading indicator

    // Close drawer before loading (improves perceived performance)
    if (MediaQuery.of(context).size.width < 700 && (_scaffoldKey.currentState?.isDrawerOpen ?? false)) {
       Navigator.of(context).pop();
       await Future.delayed(const Duration(milliseconds: 250)); // Allow drawer animation to finish
    }

    // Load the selected session's messages and attachments
    await _loadMessagesForSession(sessionId);

    // Reset UI states after loading
    if (mounted) {
      setState(() {
        _isLoading = false;
        _selectedMessageTextForCopy = null;
        _selectedMessageIndex = null;
        _isListening = false;
        _showRecordingIndicator = false;
      });
    }
  }

  // Start a new, empty chat session
  Future<void> _createNewChat() async {
     print("Creating new chat...");
     if (_isLoading) return; // Don't interrupt loading

     // Close drawer if open on small screens
     if (MediaQuery.of(context).size.width < 700 && (_scaffoldKey.currentState?.isDrawerOpen ?? false)) {
        Navigator.of(context).pop();
        await Future.delayed(const Duration(milliseconds: 250));
     }

     _setupInitialChatState(); // Reset everything to the initial state
     await _loadChatSessionsForSidebar(); // Refresh sidebar (new chat won't appear until first message)
     _textController.clear(); // Ensure text field is clear
     print("New chat created. Session ID is now null.");
  }

  // --- AI Interaction ---

  // Ask the AI model to generate a short topic for a given text (usually the first user message)
  Future<String> _getTopicFromGemini(String userQuestion) async {
  if (_model == null) return "Chat"; // Fallback if model isn't ready
  print("Generating topic for question: '$userQuestion' if the question is related to greeting just return title Greeting");
  try {
    // Use the specific topic modeling prompt
    final prompt = _topicModelingPrompt + userQuestion;
    final response = await _model!.generateContent([Content.text(prompt)]);
    final topic = response.text?.trim() ?? "Chat"; // Use "Chat" as fallback
    print("Generated topic: '$topic'");
    // Truncate long topics for display
    return topic.length > 50 ? "${topic.substring(0, 47)}..." : topic;
  } catch (e) {
    print("Error getting topic from Gemini: $e");
    return "Chat"; // Fallback on error
  }
}

  // Send the user's content (text + attachments) to the AI and handle the response
  Future<void> _getChatbotResponse(Content userContent) async {
  // userContent has already been added to _chatHistoryForAI in _sendMessage

  if (_model == null) {
    print("Error: AI Model not initialized in _getChatbotResponse.");
    _addErrorMessageToChat("Error: AI Model is not initialized.");
    // Ensure loading stops if we bail early
    if (mounted) setState(() => _isLoading = false);
    return;
  }
  // Check history length *after* userContent was added in _sendMessage
  if (_chatHistoryForAI.isEmpty) {
    print("Error: AI history is empty before sending.");
    _addErrorMessageToChat("Internal Error: Cannot send message with empty history.");
    if (mounted) setState(() => _isLoading = false);
    return;
  }

  // --- Start Streaming ---
  print("Starting AI response stream...");

  // 1. Add a placeholder message to the UI for the bot's response
  final placeholderText = "..."; // Initial text while waiting
  int botMessageIndex = -1; // Initialize with invalid index
  final initialBotMessage = AppChatMessage(text: placeholderText, isUser: false);
  if (mounted) {
    setState(() {
      _currentChatMessages.add(initialBotMessage);
      botMessageIndex = _currentChatMessages.length - 1; // Get the actual index
      // Keep _isLoading true during the streaming process
      _isLoading = true;
    });
    _scrollToBottom(); // Scroll down to show the placeholder
  }

  // If not mounted before adding placeholder, we can't proceed
  if (botMessageIndex == -1) {
     print("Error: Cannot add placeholder message, widget not mounted?");
     if (mounted) setState(() => _isLoading = false);
     return;
  }

  StringBuffer buffer = StringBuffer(); // To accumulate the full response text
  bool streamBlocked = false; // Flag to track if response was blocked by safety settings
  bool receivedAnyText = false; // Flag to track if any text chunk was received

  try {
    // 2. Use generateContentStream with the *full* chat history
    final Stream<GenerateContentResponse> responseStream =
        _model!.generateContentStream(_chatHistoryForAI);

    // 3. Listen to the stream for incoming chunks
    await for (var chunk in responseStream) {
      // Check for blocking reasons in the chunk first
      if (chunk.promptFeedback?.blockReason != null) {
        streamBlocked = true;
        final reason = chunk.promptFeedback!.blockReason;
        print("Stream blocked by safety settings. Reason: $reason");
        // Update the placeholder message with an error
        if (mounted && botMessageIndex < _currentChatMessages.length) {
          setState(() {
            _currentChatMessages[botMessageIndex] = AppChatMessage(
                text: "⚠️ Response blocked ($reason).", isUser: false);
          });
        }
        // Add distinct error message via snackbar/chat if needed
        _addErrorMessageToChat("Response blocked due to safety settings (Reason: $reason).");
        break; // Stop processing the stream
      }

      // Extract text chunk
      final textChunk = chunk.text;
      if (textChunk != null && textChunk.isNotEmpty) {
        receivedAnyText = true; // Mark that we received text
        buffer.write(textChunk); // Append chunk to the buffer

        // Update the UI by modifying the message object in the list
        if (mounted && botMessageIndex < _currentChatMessages.length) {
          setState(() {
            // Replace the message at the specific index with an updated one
            _currentChatMessages[botMessageIndex] = AppChatMessage(
              text: buffer.toString(), // Display accumulated text
              isUser: false,
            );
          });
          _scrollToBottom(delayMillis: 50); // Scroll smoothly as text grows
        }
      }
    } // End of await for loop

    // 4. Stream finished
    print("AI response stream finished.");

    // --- Post-Stream Processing ---
    // If the stream wasn't blocked
    if (!streamBlocked) {
      // If we received text content
      if (receivedAnyText) {
        final fullResponseText = buffer.toString();
        print("Full streamed response length: ${fullResponseText.length}");

        // Add the *complete* model response to the AI history for future context
        _chatHistoryForAI.add(Content("model", [TextPart(fullResponseText)]));

        // Save the complete message to the database
        if (_currentSessionId != null) {
          // Use the final message object (already updated in state)
          final finalBotMessage = _currentChatMessages[botMessageIndex];
          final timestamp = DateTime.now().millisecondsSinceEpoch;
          await _saveMessageToDatabase(finalBotMessage, _currentSessionId!, timestamp);
        }
      } else {
        // Stream finished, wasn't blocked, but no text received
        print("Stream finished with empty response.");
        if (mounted && botMessageIndex < _currentChatMessages.length && _currentChatMessages[botMessageIndex].text == placeholderText) {
           setState(() {
             _currentChatMessages[botMessageIndex] = AppChatMessage(
                 text: "⚠️ AI returned an empty response.", isUser: false);
           });
        }
        // Add empty response to history? Optional, depends if you want to track empty replies.
        // _chatHistoryForAI.add(Content("model", [TextPart("")]));
        // Save empty response to DB? Optional.
      }
    }
    // If streamBlocked, the error message is already handled inside the loop

  } on GenerativeAIException catch (e) {
    // Handle API-specific errors during streaming
    print("Generative AI Error during streaming: ${e.message}");
    // Update placeholder with error
    if (mounted && botMessageIndex < _currentChatMessages.length) {
       setState(() => _currentChatMessages[botMessageIndex] = AppChatMessage(text: "⚠️ AI Error: ${e.message}", isUser: false));
    }
    // Add distinct error message via snackbar/chat if needed
    _addErrorMessageToChat("AI Error: ${e.message}");
    streamBlocked = true; // Mark as failed
  } catch (e) {
    // Handle other unexpected errors
    print("Error during streaming response: $e");
    // Update placeholder with error
     if (mounted && botMessageIndex < _currentChatMessages.length) {
       setState(() => _currentChatMessages[botMessageIndex] = AppChatMessage(text: "⚠️ Error.", isUser: false));
    }
    // Add distinct error message via snackbar/chat if needed
    _addErrorMessageToChat("An unexpected error occurred during streaming: $e");
    streamBlocked = true; // Mark as failed
  } finally {
    // 5. Set loading to false *after* the stream completes or errors out
    if (mounted) {
      setState(() {
        _isLoading = false;
      });
    }
    print("Streaming process finished. Loading state set to false.");
  }
} // End _getChatbotResponse

  // Add an error message to the chat UI
  void _addErrorMessageToChat(String errorText) {
    if (mounted) {
      setState(() {
        // Avoid adding duplicate error messages consecutively
        if (_currentChatMessages.isEmpty || !_currentChatMessages.last.text.contains(errorText)) {
          _currentChatMessages.add(AppChatMessage(text: "⚠️ $errorText", isUser: false));
        }
        // Reset loading/listening states on error
        _isLoading = false;
        if (_isListening) {
           _isListening = false;
           _showRecordingIndicator = false;
           _speechToText.stop(); // Ensure microphone is released
        }
      });
      _scrollToBottom(); // Scroll to show the error
    }
  }

  // --- Message Sending Logic ---

  // Handles sending user input (text and/or attachments)
  Future<void> _sendMessage() async {
  final text = _textController.text.trim();

  // --- Validation Checks ---
  if ((text.isEmpty && _currentAttachments.isEmpty) || _isLoading || _isOffline || _isListening || _selectedMessageIndex != null) {
    print("Send condition not met: Text empty: ${text.isEmpty}, Attachments empty: ${_currentAttachments.isEmpty}, Loading: $_isLoading, Offline: $_isOffline, Listening: $_isListening, Msg Selected: ${_selectedMessageIndex != null}");
    return;
  }
  if (_model == null) {
     _addErrorMessageToChat("Cannot send message: AI Model is not initialized.");
     return;
  }

  // --- Prepare for Sending ---
  // Set loading true *before* any async operations start
  if (mounted) setState(() => _isLoading = true);
  final currentText = _textController.text; // Capture text before clearing
  _textController.clear(); // Clear input field
  FocusScope.of(context).unfocus(); // Hide keyboard

  // Create user message object for UI
  final userMessage = AppChatMessage(text: currentText, isUser: true);
  final timestamp = DateTime.now().millisecondsSinceEpoch;

  // Add user message to UI immediately for responsiveness
  if (mounted) {
    setState(() {
      _currentChatMessages.add(userMessage);
    });
    _scrollToBottom();
  }

  // --- Session Handling ---
  String? targetSessionId = _currentSessionId;
  bool isNewSession = false;
  if (targetSessionId == null) {
    isNewSession = true;
    print("First user message/action, creating new session...");
    targetSessionId = _uuid.v4(); // Generate a unique ID for the new session
    final topicSource = text.isNotEmpty ? text : (_currentAttachments.isNotEmpty ? _currentAttachments.first.originalName : "Chat");
    final topic = await _getTopicFromGemini(topicSource); // Ask AI for a topic
    final newSession = { 'id': targetSessionId, 'topic': topic, 'last_updated': timestamp };

    if (_database != null && _database!.isOpen) {
      try {
        await _database!.insert('sessions', newSession, conflictAlgorithm: ConflictAlgorithm.replace);
        print("New session created in DB: $targetSessionId, Topic: '$topic'");
        if (mounted) {
          setState(() { _currentSessionId = targetSessionId; _currentSessionTopic = topic; });
        }
        if (_currentAttachments.isNotEmpty) {
           await _saveAttachmentsToDatabase(_currentAttachments, targetSessionId);
        }
      } catch (e) {
        print("Error saving new session or attachments to database: $e");
        _addErrorMessageToChat("Error starting new chat session: $e");
        if (mounted) setState(() => _isLoading = false); // Stop loading on error
        return; // Abort sending
      }
    } else {
       print("Error: Database not available to save new session.");
       _addErrorMessageToChat("Error: Cannot save chat, database unavailable.");
       if (mounted) setState(() => _isLoading = false); // Stop loading on error
       return; // Abort sending
    }
  }

  // Save the user's text message to the database
  await _saveMessageToDatabase(userMessage, targetSessionId, timestamp);

  // Refresh sidebar if a new session was just created
  if (isNewSession) {
     await _loadChatSessionsForSidebar();
  }

  // --- Construct Content for AI ---
  final List<Part> parts = [];
  if (currentText.isNotEmpty) {
     String textToSend = currentText;
     if (_currentAttachments.isNotEmpty) {
        final filenames = _currentAttachments.map((a) => "'${a.originalName}'").join(', ');
        textToSend += "\n\n[System Note: Analyze the user's query. If you use information derived from the provided file(s) ($filenames) to formulate your response, please explicitly list the original filename(s) you referenced under a heading 'References:' at the very end of your response.]";
        print("Appended reference instruction to prompt.");
     }
     parts.add(TextPart(textToSend));
  }
  print("Processing ${_currentAttachments.length} attachments for sending...");
  List<AppAttachment> successfullyProcessedAttachments = [];
  for (final attachment in _currentAttachments) {
     try {
        final fileBytes = await File(attachment.storedPath).readAsBytes();
        final mimeType = attachment.mimeType ?? lookupMimeType(attachment.storedPath) ?? 'application/octet-stream';
        print("Adding DataPart: ${attachment.originalName}, MIME: $mimeType, Size: ${fileBytes.length} bytes");
        parts.add(DataPart(mimeType, fileBytes));
        successfullyProcessedAttachments.add(attachment);
     } catch (e) {
        print("Error reading or processing attachment file ${attachment.originalName} (${attachment.storedPath}): $e");
        _addErrorMessageToChat("Error processing attachment: ${attachment.originalName}. Skipping file.");
     }
  }
  final userContent = Content("user", parts);

  // --- Add user content to AI history *BEFORE* calling stream ---
  _chatHistoryForAI.add(userContent);
  print("User content added to _chatHistoryForAI (length: ${_chatHistoryForAI.length})");

  // --- Call the MODIFIED streaming response handler ---
  // Pass userContent for potential logging/consistency, though history is the primary input now
  await _getChatbotResponse(userContent);

  // Note: _isLoading is now set to false inside _getChatbotResponse's finally block
} // End _sendMessage

  // --- Connectivity Handling ---

  // Update the offline status based on connectivity results
  void _updateConnectionStatus(List<ConnectivityResult> results) {
    // Determine if currently offline (no wifi, ethernet, mobile, or vpn)
    final bool currentlyOffline = !results.contains(ConnectivityResult.wifi) &&
                                  !results.contains(ConnectivityResult.ethernet) &&
                                  !results.contains(ConnectivityResult.mobile) &&
                                  !results.contains(ConnectivityResult.vpn);

    print("Connectivity changed. Results: $results. Is Offline: $currentlyOffline");

    // Update state only if the status actually changed
    if (_isOffline != currentlyOffline) {
      if (mounted) {
        setState(() => _isOffline = currentlyOffline);
        if (!currentlyOffline) {
          // Came back online
          _showSnackbar("Back online!", duration: const Duration(seconds: 2), bgColor: Colors.green[700]);
          _resendLastPendingMessageIfNeeded(); // Attempt to resend buffered message
        } else {
          // Went offline
          _showSnackbar("You are offline. Messages and new attachments cannot be sent.", duration: const Duration(seconds: 4), bgColor: Colors.orange[800]);
          // If listening to voice, stop it as it requires network
          if (_isListening) {
             print("Went offline, cancelling speech recognition.");
             _stopListening(cancel: true);
          }
        }
      }
    }
  }

  // Simple mechanism to resend the last typed message if connection returns
  // Note: This does NOT handle attachments added while offline. A more robust queue is needed for that.
  void _resendLastPendingMessageIfNeeded() {
    if (_lastUserMessagePendingSend != null && !_isOffline && !_isLoading) {
      print("Resending pending text message...");
      final messageToSend = _lastUserMessagePendingSend!;
      _lastUserMessagePendingSend = null; // Clear buffer
      _textController.text = messageToSend.text; // Put text back in field
      _sendMessage(); // Trigger send process again (will include any *current* attachments)
    }
  }

  // --- Helper Method to Clear Message Selection ---
  void _clearSelection() {
    if (_selectedMessageIndex != null || _selectedMessageTextForCopy != null) {
      if (mounted) {
        setState(() {
          _selectedMessageIndex = null;
          _selectedMessageTextForCopy = null;
        });
        print("Selection cleared.");
      }
    }
  }

  // --- NEW: File Picking and Handling ---

  // Get the dedicated directory for storing uploaded files within the app's documents folder
  Future<Directory> _getUploadsDirectory() async {
     final appDocsDir = await getApplicationDocumentsDirectory();
     final uploadsDir = Directory(p.join(appDocsDir.path, 'uploads'));
     // Create the directory if it doesn't exist
     if (!await uploadsDir.exists()) {
        try {
           await uploadsDir.create(recursive: true);
           print("Created uploads directory: ${uploadsDir.path}");
        } catch (e) {
           print("Error creating uploads directory: $e");
           // Rethrow or handle? For now, let subsequent operations fail.
           throw Exception("Could not create uploads directory: $e");
        }
     }
     return uploadsDir;
  }

  // Trigger the file picker and process selected files
  Future<void> _pickFiles() async {
    // Prevent picking if busy, offline, or listening
    if (_isLoading || _isOffline || _isListening) return;

    print("Attempting to pick files...");
    try {
      // Use file_picker to open the native file selection UI
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        allowMultiple: true, // Allow selecting multiple files
        type: FileType.custom, // Specify allowed extensions
        // Define allowed file extensions (adjust as needed)
        allowedExtensions: [
          // Documents
          'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', // MS Office
          'odt', 'ods', 'odp', // OpenDocument
          'txt', 'csv', 'rtf', 'json', 'xml', 'html', // Text/Data
          // Images
          'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'heic', 'heif',
          // Archives (Gemini might not process content well, but can list files)
          // 'zip', 'tar', 'gz',
          // Audio/Video (Check Gemini support/limits - often large)
          // 'mp3', 'wav', 'mp4', 'mov', 'avi',
        ],
        // Avoid reading file data immediately unless necessary (memory usage)
        // withData: false,
        withReadStream: false, // Not needed for copying
      );

      // If user selected files
      if (result != null && result.files.isNotEmpty) {
        print("Picked ${result.files.length} files.");
        final uploadsDir = await _getUploadsDirectory(); // Get storage location
        int addedCount = 0;
        List<AppAttachment> newlyAdded = []; // Temp list for newly added files

        if (mounted) setState(() => _isLoading = true); // Show loading while copying

        // Process each selected file
        for (PlatformFile file in result.files) {
          // Check if file path is valid (should generally be)
          if (file.path == null) {
             print("Warning: Picked file '${file.name}' has no path. Skipping.");
             _showSnackbar("Skipped file '${file.name}' (Invalid path).", bgColor: Colors.orange[800]);
             continue;
          }

          final sourceFile = File(file.path!);
          final uniqueId = _uuid.v4(); // Generate unique ID for storage/DB
          final extension = p.extension(file.name); // Get original extension
          final newFileName = '$uniqueId$extension'; // Create unique filename
          final destinationPath = p.join(uploadsDir.path, newFileName); // Full destination path

          try {
             print("Copying '${file.name}' to '$destinationPath'...");
             // Copy the file from the picker's cache to our app's directory
             await sourceFile.copy(destinationPath);

             // Attempt to determine MIME type (read header for better accuracy)
             String? mimeType;
             try {
                // Read first 1KB to help mime package identify type
                final headerBytes = await File(destinationPath).openRead(0, 1024).first;
                mimeType = lookupMimeType(destinationPath, headerBytes: headerBytes);
             } catch (mimeError) {
                print("Could not read header for MIME type detection for ${file.name}: $mimeError");
                // Fallback to extension-based lookup
                mimeType = lookupMimeType(destinationPath);
             }
             print("File copied. Original: ${file.name}, Stored: $newFileName, MIME: $mimeType");

             // Create attachment object
             final newAttachment = AppAttachment(
                id: uniqueId, // Use the generated UUID as the attachment record ID
                originalName: file.name,
                storedPath: destinationPath,
                mimeType: mimeType,
             );
             newlyAdded.add(newAttachment);
             addedCount++;
          } catch (e) {
             // Handle errors during file copy
             print("Error copying file '${file.name}': $e");
             _showSnackbar("Error processing file: ${file.name}", bgColor: Colors.redAccent);
             // Optionally try to delete partially copied file if possible
          }
        } // End loop through picked files

        // Update state with newly added attachments
        if (mounted) {
           setState(() {
              _currentAttachments.addAll(newlyAdded);
              _isLoading = false; // Hide loading indicator
           });
           // Show success message
           if (addedCount > 0) {
              _showSnackbar("$addedCount file(s) attached successfully!");
           }
        }

        // Note on saving attachments immediately for new chats:
        // The current logic saves attachments to the DB only when the *first* message
        // is sent (which creates the session). This is generally fine.
        // If immediate saving upon attachment (before first message) is required,
        // the logic in _sendMessage and session creation would need adjustment.

      } else {
        // User canceled the picker or no files were selected
        print("File picking cancelled or no files selected.");
      }
    } on PlatformException catch (e) {
       // Handle platform-specific errors from file_picker (e.g., permissions)
       print("File Picker PlatformException: ${e.code} - ${e.message}");
       _showSnackbar("File picker error: ${e.message}", bgColor: Colors.redAccent);
       if (mounted) setState(() => _isLoading = false);
    } catch (e) {
      // Handle other unexpected errors during picking/processing
      print("Error picking files: $e");
      if (mounted) {
         _showSnackbar("Error picking files: $e", bgColor: Colors.redAccent);
         setState(() => _isLoading = false); // Ensure loading stops on error
      }
    }
  }

  // Remove an attachment from the current session
  void _removeAttachment(int index) {
     // Basic validation
     if (index < 0 || index >= _currentAttachments.length || _isLoading) return;

     final attachmentToRemove = _currentAttachments[index];
     print("Attempting to remove attachment: ${attachmentToRemove.originalName}");

     // Show confirmation dialog before removing
     showDialog<bool>(
       context: context,
       builder: (context) => AlertDialog(
         title: const Text("Remove Attachment?"),
         content: Text("Are you sure you want to remove '${attachmentToRemove.originalName}'?"),
         actions: [
           TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text("Cancel")),
           TextButton(
             style: TextButton.styleFrom(foregroundColor: Colors.redAccent),
             onPressed: () => Navigator.of(context).pop(true), // Confirm removal
             child: const Text("Remove")
           ),
         ],
       )
     ).then((confirmed) async { // Process confirmation result
        if (confirmed == true) {
           print("User confirmed removal of ${attachmentToRemove.originalName}");
           // 1. Remove from UI state
           if (mounted) {
              setState(() {
                 _currentAttachments.removeAt(index);
              });
              print("Attachment removed from UI state.");
           }

           // 2. Delete record from database IF the session exists
           if (_currentSessionId != null && _database != null && _database!.isOpen) {
              try {
                 int deletedRows = await _database!.delete(
                    'session_attachments',
                    // Use the unique attachment ID for precise deletion
                    where: 'id = ? AND session_id = ?',
                    whereArgs: [attachmentToRemove.id, _currentSessionId],
                 );
                 print("Attachment record deleted from DB ($deletedRows rows affected) for session $_currentSessionId.");
              } catch (e) {
                 print("Error deleting attachment record from DB: $e");
                 // Log error, but UI state is already updated, so proceed
              }
           } else {
              print("Attachment removal: Session not yet saved or DB unavailable. Skipping DB delete.");
           }

           // 3. Delete the actual file from local storage
           try {
              final file = File(attachmentToRemove.storedPath);
              if (await file.exists()) {
                 await file.delete();
                 print("Attachment file deleted from storage: ${attachmentToRemove.storedPath}");
              } else {
                 print("Attachment file not found at ${attachmentToRemove.storedPath} for deletion.");
              }
           } catch (e) {
              print("Error deleting attachment file from storage: $e");
              // Log error, but UI/DB state is handled
           }
           _showSnackbar("Attachment '${attachmentToRemove.originalName}' removed.");
        } else {
           print("User cancelled attachment removal.");
        }
     });
  }


  // --- NEW: Speech-to-Text Logic ---

  // Start listening for voice input
  void _startListening() async {
    // Check conditions preventing listening
    if (!_speechEnabled || _isListening || _isLoading || _isOffline) {
       print("Start listening condition not met: Enabled: $_speechEnabled, Listening: $_isListening, Loading: $_isLoading, Offline: $_isOffline");
       if (!_speechEnabled && mounted) {
          _showSnackbar("Voice input not available. Check permissions or initialization.", bgColor: Colors.orange[800]);
       } else if (_isOffline && mounted) {
          _showSnackbar("Voice input requires an internet connection.", bgColor: Colors.orange[800]);
       }
       return;
    }

    // Double-check microphone permission just before starting
    var micStatus = await Permission.microphone.status;
    if (!micStatus.isGranted) {
       print("Microphone permission not granted before starting listen.");
       if (mounted) _showSnackbar("Microphone permission required.", bgColor: Colors.orange[800]);
       // Optionally re-request here, or guide user to settings
       // await _requestPermissions(); // Re-request
       // micStatus = await Permission.microphone.status;
       // if (!micStatus.isGranted) return; // Exit if still not granted
       return;
    }

    print("Starting speech recognition...");
    _lastRecognizedWords = ""; // Clear buffer for previous results

    try {
       // Start listening using the speech_to_text plugin
       await _speechToText.listen(
          onResult: _onSpeechResult, // Callback for recognized words
          listenFor: const Duration(seconds: 30), // Maximum recording duration
          pauseFor: const Duration(seconds: 3), // Auto-stop after 3s pause
          localeId: "en_US", // Optional: Specify language locale
          // cancelOnError: true, // Optional: Stop listening on error
          // partialResults: true, // Optional: Get intermediate results (handled in _onSpeechResult)
          // listenMode: ListenMode.confirmation, // Optional: Different listening modes
       );
       // Update UI state to reflect listening
       if (mounted) {
          setState(() {
             _isListening = true;
             _showRecordingIndicator = true; // Show AppBar indicator
          });
          print("Speech recognition listening...");
       }
    } catch (e) {
       print("Error starting speech recognition: $e");
       if (mounted) {
          _addErrorMessageToChat("Error starting voice input: $e");
          // Reset state on error
          setState(() {
             _isListening = false;
             _showRecordingIndicator = false;
          });
       }
    }
  }

  // Stop listening for voice input
  // `cancel`: If true, discard any partial results. If false, process the final result.
  void _stopListening({bool cancel = false}) async {
    if (!_isListening) return; // Don't stop if not listening

    print("Stopping speech recognition... Cancel: $cancel");
    try {
       if (cancel) {
          await _speechToText.cancel(); // Cancel immediately, discard results
       } else {
          await _speechToText.stop(); // Stop gracefully, allow final result processing
       }
    } catch (e) {
       // Log error but proceed with state update
       print("Error stopping/cancelling speech recognition: $e");
    } finally {
       // Ensure state is updated regardless of errors during stop/cancel
       if (mounted) {
          setState(() {
             _isListening = false;
             _showRecordingIndicator = false; // Hide AppBar indicator
          });
          // Populate text field only if NOT cancelled and words were recognized
          if (!cancel && _lastRecognizedWords.isNotEmpty) {
             _textController.text = _lastRecognizedWords; // Set text field content
             // Move cursor to the end of the inserted text
             _textController.selection = TextSelection.fromPosition(
                TextPosition(offset: _textController.text.length)
             );
             print("Populated text field with: '$_lastRecognizedWords'");
          } else {
             print("Listening stopped/cancelled without populating text field.");
          }
          // Clear the recognized words buffer after processing
          _lastRecognizedWords = "";
       }
    }
  }


  // Callback invoked by speech_to_text when words are recognized
  void _onSpeechResult(SpeechRecognitionResult result) {
    if (mounted) {
      // Update the buffer with the latest recognized words
      setState(() {
        _lastRecognizedWords = result.recognizedWords;
        // Optional: Update text field live as user speaks? Can be distracting.
        // _textController.text = _lastRecognizedWords;
        // _textController.selection = TextSelection.fromPosition(TextPosition(offset: _textController.text.length));
      });
       print("Speech Result (final: ${result.finalResult}): '${result.recognizedWords}'");
       // Optional: Auto-stop if a final result is received?
       // if (result.finalResult) {
       //    _stopListening();
       // }
    }
  }

  // Callback invoked by speech_to_text on status changes (listening, notListening, done)
  void _speechStatusListener(String status) {
    print("Speech Recognition Status: $status");
    if (mounted) {
       // Keep UI state consistent with actual STT status
       final isActuallyListening = status == SpeechToText.listeningStatus;
       if (_isListening != isActuallyListening) {
          print("STT status changed listening state. Updating UI.");
          setState(() {
             _isListening = isActuallyListening;
             _showRecordingIndicator = isActuallyListening; // Sync indicator
             // If status changes to not listening unexpectedly, handle potential results
             if (!_isListening && _lastRecognizedWords.isNotEmpty) {
                // Populate text field if stopped unexpectedly with results
                _textController.text = _lastRecognizedWords;
                _textController.selection = TextSelection.fromPosition(TextPosition(offset: _textController.text.length));
                print("Populated text field on status change to not listening: '$_lastRecognizedWords'");
                _lastRecognizedWords = ""; // Clear buffer
             } else if (!_isListening) {
                _lastRecognizedWords = ""; // Clear buffer if stopped without result
             }
          });
       }
    }
  }

  // Callback invoked by speech_to_text on errors
  void _speechErrorListener(SpeechRecognitionError error) {
    print("Speech Recognition Error: ${error.errorMsg} (Permanent: ${error.permanent})");
    if (mounted) {
      // Show error in chat and reset listening state
      _addErrorMessageToChat("Voice input error: ${error.errorMsg}");
      setState(() {
        _isListening = false;
        _showRecordingIndicator = false;
      });
    }
  }


  // --- UI Building Methods ---

  // Build the AppBar, handling default, copy, offline, and recording states
  AppBar _buildAppBar() {
     // --- Build Copy Action Bar ---
     if (_selectedMessageIndex != null && _selectedMessageTextForCopy != null) {
       return AppBar(
         leading: IconButton(
           icon: const Icon(Icons.close),
           tooltip: "Cancel Selection",
           onPressed: _clearSelection,
         ),
         title: const Text("1 message selected"),
         backgroundColor: Theme.of(context).colorScheme.primaryContainer,
         actions: [
           IconButton(
             icon: const Icon(Icons.copy_all_outlined),
             tooltip: "Copy Text",
             onPressed: () {
               Clipboard.setData(ClipboardData(text: _selectedMessageTextForCopy!));
               _showSnackbar("Message copied to clipboard");
               _clearSelection();
             },
           ),
         ],
       );
     }

     // --- Build Default App Bar ---
     return AppBar(
       title: const Text("Answerhub on m2s Q&A"), // Show current topic or default
       centerTitle: true,
       // Show menu button for drawer on small screens
       leading: MediaQuery.of(context).size.width < 700
           ? IconButton(
               icon: const Icon(Icons.menu),
               tooltip: "Toggle History",
               // Disable if busy or selecting
               onPressed: (_isLoading || _selectedMessageIndex != null || _isListening) ? null : () {
                 _scaffoldKey.currentState?.openDrawer(); // Open drawer
               },
             )
           : null, // No leading button on large screens
       // --- Combined Offline and Recording Indicators ---
       bottom: PreferredSize(
         // Calculate height based on which indicators are visible
         preferredSize: Size.fromHeight(
             (_isOffline ? 24.0 : 0) + (_showRecordingIndicator ? 24.0 : 0)
         ),
         child: Column(
           mainAxisSize: MainAxisSize.min, // Take only needed vertical space
           children: [
             // Recording Indicator (Shows on top if both are visible)
             if (_showRecordingIndicator)
               Material(
                 color: Colors.redAccent[700], // Distinct color for recording
                 child: Container(
                   height: 24.0, // Fixed height
                   padding: const EdgeInsets.symmetric(horizontal: 16.0),
                   child: const Row(
                     mainAxisAlignment: MainAxisAlignment.center,
                     children: [
                       Icon(Icons.mic, size: 16, color: Colors.white),
                       SizedBox(width: 8),
                       Text(
                         "Recording... Release to stop",
                         style: TextStyle(color: Colors.white, fontSize: 12),
                       ),
                     ],
                   ),
                 ),
               ),
             // Offline Indicator (Shows below recording indicator if both visible)
             if (_isOffline)
               Material(
                 color: Colors.orange[800], // Distinct color for offline
                 child: InkWell( // Allow tapping to recheck connection
                   onTap: () {
                      if (mounted) {
                         _showSnackbar("Rechecking connection...", duration: const Duration(seconds: 1));
                         Connectivity().checkConnectivity().then(_updateConnectionStatus);
                      }
                   },
                   child: Container(
                     height: 24.0, // Fixed height
                     padding: const EdgeInsets.symmetric(horizontal: 16.0),
                     child: const Row(
                       mainAxisAlignment: MainAxisAlignment.center,
                       children: [
                         Icon(Icons.signal_wifi_off_outlined, size: 16, color: Colors.white),
                         SizedBox(width: 8),
                         Text(
                           "Offline - Tap to recheck connection",
                           style: TextStyle(color: Colors.white, fontSize: 12),
                         ),
                       ],
                     ),
                   ),
                 ),
               ),
           ],
         ),
       ),
     );
   }

   // Build the content of the sidebar/drawer displaying chat history
   Widget _buildSidebarContent() {
     return Column(
       children: [
         // --- New Chat Button ---
         Padding(
           padding: const EdgeInsets.all(8.0),
           child: ElevatedButton.icon(
             icon: const Icon(Icons.add),
             label: const Text("New Chat"),
             style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(40)),
             // Disable if busy
             onPressed: _isLoading ? null : _createNewChat,
           ),
         ),
         const Divider(height: 1),
         // --- Chat History List ---
         Expanded(
           child: _chatSessionsForSidebar.isEmpty
               // Show message if history is empty
               ? const Center(
                   child: Padding(
                     padding: EdgeInsets.all(16.0),
                     child: Text(
                       "No chat history yet.",
                       style: TextStyle(color: Colors.grey),
                       textAlign: TextAlign.center,
                     ),
                   ),
                 )
               // Build list view of sessions
               : ListView.builder(
                   itemCount: _chatSessionsForSidebar.length,
                   itemBuilder: (context, index) {
                     final session = _chatSessionsForSidebar[index];
                     final sessionId = session['id'] as String?;
                     final topic = session['topic'] as String? ?? 'Chat'; // Fallback topic
                     if (sessionId == null) return const SizedBox.shrink(); // Skip invalid entries

                     final bool isSelected = sessionId == _currentSessionId; // Highlight current session

                     return ListTile(
                       leading: Icon(
                          Icons.chat_bubble_outline,
                          size: 18,
                          color: isSelected ? Theme.of(context).colorScheme.primary : null
                       ),
                       title: Text(
                         topic,
                         maxLines: 1,
                         overflow: TextOverflow.ellipsis,
                         style: TextStyle(fontWeight: isSelected ? FontWeight.bold : FontWeight.normal),
                       ),
                       selected: isSelected,
                       selectedTileColor: Theme.of(context).highlightColor.withOpacity(0.15),
                       dense: true, // Make list items smaller
                       onTap: () => _loadChatSession(sessionId), // Load session on tap
                       // Delete button for each session
                       trailing: IconButton(
                          icon: Icon(Icons.delete_outline, size: 18, color: Colors.grey[600]),
                          tooltip: "Delete this chat",
                          visualDensity: VisualDensity.compact,
                          padding: EdgeInsets.zero,
                          // Disable delete if busy
                          onPressed: _isLoading ? null : () => _deleteSingleSession(sessionId, topic),
                       ),
                     );
                   },
                 ),
         ),
         const Divider(height: 1),
         // --- Clear All History Button ---
         ListTile(
           leading: const Icon(Icons.delete_sweep_outlined, size: 20),
           title: const Text("Clear All History"),
           dense: true,
           // Disable if busy or no history exists
           enabled: !_isLoading && _chatSessionsForSidebar.isNotEmpty,
           onTap: (_isLoading || _chatSessionsForSidebar.isEmpty || _isListening) ? null : _clearChatHistory,
         ),
         // --- About Button ---
         ListTile(
           leading: const Icon(Icons.info_outline, size: 20),
           title: const Text("About"),
           dense: true,
           onTap: () {
             // Close drawer if open
             if (_scaffoldKey.currentState?.isDrawerOpen ?? false) {
               Navigator.of(context).pop();
             }
             // Show About Dialog
             showDialog(
               context: context,
               builder: (context) => AlertDialog(
                 title: const Text("About Answerhub on m2s Q&A"),
                 content: Column(
                   mainAxisSize: MainAxisSize.min,
                   crossAxisAlignment: CrossAxisAlignment.start,
                   children: [
                     const Text("A chat application powered by Google Gemini."),
                     const SizedBox(height: 16),
                     InkWell(
                       child: Text(
                         "Learn more about Google AI",
                         style: TextStyle(color: Theme.of(context).colorScheme.primary, decoration: TextDecoration.underline),
                       ),
                       onTap: () => _launchUrl("https://ai.google/", context),
                     ),
                     const SizedBox(height: 8),
                     InkWell(
                       child: Text(
                         "View Gemini API Docs",
                         style: TextStyle(color: Theme.of(context).colorScheme.primary, decoration: TextDecoration.underline),
                       ),
                       onTap: () => _launchUrl("https://ai.google.dev/docs", context),
                     ),
                   ],
                 ),
                 actions: [
                   TextButton(
                     child: const Text("Close"),
                     onPressed: () => Navigator.of(context).pop(),
                   ),
                 ],
               ),
             );
           },
         ),
         const SizedBox(height: 8), // Bottom padding
       ],
     );
   }

   // Build the row of chips displaying currently attached files
   Widget _buildAttachmentChips() {
     // Return empty space if no attachments
     if (_currentAttachments.isEmpty) {
       return const SizedBox.shrink();
     }

     return Padding(
       // Padding around the chip area
       padding: const EdgeInsets.only(left: 8.0, right: 8.0, top: 4.0, bottom: 0),
       child: Wrap( // Allows chips to wrap to the next line
         spacing: 6.0, // Horizontal space between chips
         runSpacing: 0.0, // Vertical space between lines (set to 0 or small value)
         children: List<Widget>.generate(_currentAttachments.length, (index) {
           final attachment = _currentAttachments[index];
           return Chip(
             // Display original filename (truncated if too long)
             label: Text(
               attachment.originalName,
               overflow: TextOverflow.ellipsis,
             ),
             labelPadding: const EdgeInsets.only(left: 8.0), // Space between icon and label
             padding: EdgeInsets.zero, // Minimize chip internal padding
             // Show a file icon
             avatar: Icon(Icons.attach_file, size: 16, color: Theme.of(context).colorScheme.onSecondaryContainer),
             backgroundColor: Theme.of(context).colorScheme.secondaryContainer, // Use theme color
             labelStyle: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSecondaryContainer),
             // Delete button for removing the attachment
             deleteIcon: const Icon(Icons.cancel, size: 18),
             deleteIconColor: Theme.of(context).colorScheme.onSecondaryContainer.withOpacity(0.7),
             // Call _removeAttachment when delete icon is tapped
             // Disable deletion if busy
             onDeleted: _isLoading || _isListening ? null : () => _removeAttachment(index),
             materialTapTargetSize: MaterialTapTargetSize.shrinkWrap, // Reduce tap target size
             visualDensity: VisualDensity.compact, // Make chip visually smaller
           );
         }),
       ),
     );
   }


   // Build the bottom input area (attachments, voice, text field, send button)
      // Build the bottom input area (attachments, voice, text field, send button)
   Widget _buildTextInputArea() {
    return Padding(
      // Adjust padding based on keyboard visibility
      padding: EdgeInsets.only(
          left: 8.0,
          right: 8.0,
          bottom: MediaQuery.of(context).viewInsets.bottom + 8.0, // Add padding when keyboard is up
          top: 4.0),
      child: Column( // Use Column to stack attachment chips above the input row
        mainAxisSize: MainAxisSize.min, // Take minimum vertical space
        children: [
          // --- Display Attachment Chips ---
          _buildAttachmentChips(),

          // --- Row for Icons, Text Field, Send Button ---
          Row(
            crossAxisAlignment: CrossAxisAlignment.end, // Align items to bottom
            children: [
              // --- Attachment Button ---
              IconButton(
                icon: const Icon(Icons.add_circle_outline),
                tooltip: "Attach File",
                iconSize: 26,
                padding: const EdgeInsets.only(bottom: 10, right: 4), // Align visually
                // Disable if loading, offline, or listening
                onPressed: (_isLoading || _isOffline || _isListening) ? null : _pickFiles,
              ),

              // --- Voice Input Button ---
              GestureDetector(
                // Trigger start/stop listening on long press gestures
                onLongPressStart: (_isLoading || _isOffline || !_speechEnabled) ? null : (_) => _startListening(),
                onLongPressEnd: (_) => _stopListening(),
                onLongPressCancel: () => _stopListening(cancel: true), // Cancel if gesture breaks
                child: IconButton(
                  // Change icon based on listening state
                  icon: Icon(_isListening ? Icons.mic_off_outlined : Icons.mic_none_outlined),
                  tooltip: _isListening ? "Recording... Release to stop" : "Hold to Record Voice",
                  iconSize: 26,
                  padding: const EdgeInsets.only(bottom: 10, left: 0, right: 4), // Align visually
                  // Disable visual feedback if conditions not met (GestureDetector handles actual press logic)
                  onPressed: (_isLoading || _isOffline || !_speechEnabled) ? null : () {
                     // Optional: Action for a short tap? Maybe show tooltip or error?
                     if (!_speechEnabled && mounted) {
                        _showSnackbar("Voice input not available.", bgColor: Colors.orange[800]);
                     } else if (_isOffline && mounted) {
                        _showSnackbar("Voice input requires connection.", bgColor: Colors.orange[800]);
                     }
                  },
                  // Highlight icon when listening
                  color: _isListening ? Theme.of(context).colorScheme.primary : null,
                ),
              ),

              // --- Text Field ---
              Expanded(
                child: TextField(
                  controller: _textController,
                  minLines: 1,
                  maxLines: 5, // Allow multi-line input
                  textCapitalization: TextCapitalization.sentences,
                  style: const TextStyle(fontSize: 16),
                  decoration: InputDecoration(
                    // Dynamic hint text based on state
                    hintText: _isOffline ? "Offline - Cannot send"
                            : _isListening ? "Listening..."
                            : "Type message or add files...",
                    isDense: true, // Reduce vertical padding
                    filled: true, // Add background fill
                    fillColor: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.5),
                    border: OutlineInputBorder(
                       borderRadius: BorderRadius.circular(20.0),
                       borderSide: BorderSide.none, // No visible border
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
                  ),
                  // Send message on keyboard submit action
                  onSubmitted: (_isLoading || _isOffline || _isListening || _selectedMessageIndex != null) ? null : (_) => _sendMessage(),
                  textInputAction: TextInputAction.send,
                  // Disable input field if busy, offline, listening, or selecting message
                  enabled: !_isLoading && !_isOffline && !_isListening && _selectedMessageIndex == null,

                  // --- CORRECTED onChanged ---
                  onChanged: (text) {
                     // Simply call setState to rebuild and re-evaluate the send button's onPressed condition
                     setState(() {});
                  },
                  // --- END CORRECTION ---

                ),
              ),
              const SizedBox(width: 8), // Space before send button

              // --- Send Button ---
              IconButton.filled( // Use filled style for prominence
                icon: const Icon(Icons.send),
                tooltip: "Send Message",
                iconSize: 24,
                // Disable send if: busy, offline, listening, selecting message,
                // OR if text is empty AND no attachments are present
                onPressed: (_isLoading || _isOffline || _isListening || _selectedMessageIndex != null || (_textController.text.trim().isEmpty && _currentAttachments.isEmpty))
                           ? null // Disable button
                           : _sendMessage, // Enable button
                 padding: const EdgeInsets.all(12), // Adjust padding as needed
              ),
            ],
          ),
        ],
      ),
    );
   }


  // --- Main Build Method ---
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final bool isLargeScreen = screenWidth >= 700; // Threshold for showing permanent sidebar

    // --- Chat List Widget ---
    // Builds the scrollable list of chat messages
     Widget chatList = ListView.builder(
       controller: _chatScrollController, // Attach scroll controller
       padding: const EdgeInsets.symmetric(vertical: 8.0), // Padding around the list
       itemCount: _currentChatMessages.length,
       itemBuilder: (context, index) {
         final message = _currentChatMessages[index];
         // Use a unique key if messages can be reordered or frequently updated
         // final key = ValueKey('${message.timestamp}_${message.isUser}');

         // Use the dedicated ChatMessageWidget for rendering
         return ChatMessageWidget(
           key: ValueKey(index), // Simple index key is often sufficient if list only appends
           text: message.text,      // Use 'text' parameter name instead of 'message'
           index: index,
           isUser: message.isUser,
           // Pass callbacks for long press (copy) and tap (clear selection)
           onLongPress: () {
             if (mounted) {
               setState(() {
                 _selectedMessageIndex = index;
                 _selectedMessageTextForCopy = message.text;
               });
               print("Selected message $index for copy.");
             }
           },
           onTap: _clearSelection,
           isSelected: _selectedMessageIndex == index, // Highlight if selected
         );
       },
     );

     // --- Main Chat Area Column ---
     // Contains the chat list and the input area
     Widget chatArea = Column(
       children: [
         // The scrollable chat message list
         Expanded(
           child: GestureDetector(
             // Allow tapping empty space in chat area to clear selection/focus
             onTap: () {
               _clearSelection();
               FocusScope.of(context).unfocus(); // Hide keyboard
             },
             behavior: HitTestBehavior.translucent, // Ensure tap hits empty space
             child: chatList,
           ),
         ),
         // Show linear progress indicator ONLY when actively sending/receiving online AND not listening
         if (_isLoading && !_isOffline && !_isListening)
             const Padding(
                padding: EdgeInsets.symmetric(vertical: 0, horizontal: 0), // No extra padding
                child: LinearProgressIndicator(minHeight: 2), // Thin indicator
             ),
         // The bottom input area
         _buildTextInputArea(),
       ],
     );

    // --- Scaffold Structure ---
    return Scaffold(
      key: _scaffoldKey, // Key for accessing drawer state
      appBar: _buildAppBar(), // Build the dynamic AppBar
      // Use Drawer only on small screens
      drawer: isLargeScreen ? null : Drawer(child: _buildSidebarContent()),
      body: Row( // Use Row for large screen layout (sidebar + chat)
        children: [
          // Show permanent sidebar on large screens
          if (isLargeScreen)
              SizedBox(
                width: 280, // Width of the sidebar
                child: Material(
                  elevation: 1.0, // Subtle shadow
                  color: Theme.of(context).canvasColor, // Use theme background
                  child: _buildSidebarContent(), // Build sidebar content
                ),
              ),
          // Vertical divider between sidebar and chat on large screens
          if (isLargeScreen) const VerticalDivider(width: 1, thickness: 1),
          // Main chat area takes remaining space
          Expanded(
            child: chatArea,
          ),
        ],
      ),
    );
  }

  // --- Helper Methods ---

  // Scroll the chat list to the bottom, with throttling
  void _scrollToBottom({int delayMillis = 50}) {
    _updateThrottleTimer?.cancel(); // Cancel previous pending scroll
    // Schedule scroll after a short delay to allow UI to build
    _updateThrottleTimer = Timer(Duration(milliseconds: delayMillis), () {
      // Check if controller is attached and has dimensions
      if (_chatScrollController.hasClients && _chatScrollController.position.hasContentDimensions) {
        _chatScrollController.animateTo(
          _chatScrollController.position.maxScrollExtent, // Scroll to the very end
          duration: const Duration(milliseconds: 300), // Animation duration
          curve: Curves.easeOutQuad, // Animation curve
        );
      }
    });
  }

  // Show a SnackBar notification
  void _showSnackbar(String message, {Duration duration = const Duration(seconds: 3), Color? bgColor}) {
    if (!mounted) return; // Don't show if widget is disposed
    ScaffoldMessenger.of(context).hideCurrentSnackBar(); // Hide previous snackbar
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: duration,
        backgroundColor: bgColor, // Optional background color
        behavior: SnackBarBehavior.floating, // Make it float above bottom elements
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        margin: const EdgeInsets.all(8), // Margin around the snackbar
      ),
    );
    print("Snackbar shown: '$message'");
  }

  // Launch a URL using url_launcher
  Future<void> _launchUrl(String url, BuildContext context) async {
    final uri = Uri.parse(url);
    if (!await canLaunchUrl(uri)) {
      if (mounted) {
        _showSnackbar('Could not launch $url', bgColor: Colors.redAccent);
      }
      print("Could not launch URL: $url");
    } else {
      try {
         await launchUrl(uri, mode: LaunchMode.externalApplication); // Open in external browser
      } catch (e) {
         if (mounted) {
           _showSnackbar('Error launching URL: $e', bgColor: Colors.redAccent);
         }
         print("Error launching URL $url: $e");
      }
    }
  }

} // End _ChatScreenState
